//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CsA41UeR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/contact",
			"/services"
		],
		preloads: ["/assets/index-CvumA9ol.js", "/assets/jsx-runtime-bzQ4Vb5N.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CvumA9ol.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CF_liunw.js", "/assets/after-BnwPPy0P.js"]
	},
	"/about": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-DLNo5Oaj.js"]
	},
	"/contact": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-CJIktK6i.js"]
	},
	"/services": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.tsx",
		children: [
			"/services/aesthetic",
			"/services/injectables",
			"/services/laser",
			"/services/lifting",
			"/services/skin",
			"/services/surgery",
			"/services/wellness",
			"/services/",
			"/services/dental/cosmetic-dentistry",
			"/services/dental/general",
			"/services/dental/implants",
			"/services/dental/orthodontics",
			"/services/dental/whitening"
		],
		preloads: ["/assets/services-DKsgce_X.js"]
	},
	"/services/aesthetic": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.aesthetic.tsx",
		children: void 0,
		preloads: ["/assets/services.aesthetic-CO_Vy2qh.js"]
	},
	"/services/injectables": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.injectables.tsx",
		children: void 0,
		preloads: ["/assets/services.injectables-CpaQbeLz.js", "/assets/ServiceTemplate-BeykL8VT.js"]
	},
	"/services/laser": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.laser.tsx",
		children: void 0,
		preloads: ["/assets/services.laser-Bm0qYciM.js", "/assets/ServiceTemplate-BeykL8VT.js"]
	},
	"/services/lifting": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.lifting.tsx",
		children: void 0,
		preloads: ["/assets/services.lifting-B4k3wV_d.js", "/assets/ServiceTemplate-BeykL8VT.js"]
	},
	"/services/skin": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.skin.tsx",
		children: void 0,
		preloads: ["/assets/services.skin-BMIgoIbA.js", "/assets/ServiceTemplate-BeykL8VT.js"]
	},
	"/services/surgery": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.surgery.tsx",
		children: void 0,
		preloads: ["/assets/services.surgery-B14ID3s9.js", "/assets/ServiceTemplate-BeykL8VT.js"]
	},
	"/services/wellness": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.wellness.tsx",
		children: void 0,
		preloads: ["/assets/services.wellness-ChHMwvIQ.js"]
	},
	"/services/": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.index.tsx",
		children: void 0,
		preloads: ["/assets/services.index-B83JEIHa.js"]
	},
	"/services/dental/cosmetic-dentistry": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.dental.cosmetic-dentistry.tsx",
		children: void 0,
		preloads: ["/assets/services.dental.cosmetic-dentistry-DAescyuo.js", "/assets/ServiceTemplate-BeykL8VT.js"]
	},
	"/services/dental/general": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.dental.general.tsx",
		children: void 0,
		preloads: ["/assets/services.dental.general-CrsQgxtV.js", "/assets/ServiceTemplate-BeykL8VT.js"]
	},
	"/services/dental/implants": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.dental.implants.tsx",
		children: void 0,
		preloads: ["/assets/services.dental.implants-Ck3DQevi.js", "/assets/ServiceTemplate-BeykL8VT.js"]
	},
	"/services/dental/orthodontics": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.dental.orthodontics.tsx",
		children: void 0,
		preloads: ["/assets/services.dental.orthodontics-BoSf57OP.js", "/assets/ServiceTemplate-BeykL8VT.js"]
	},
	"/services/dental/whitening": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.dental.whitening.tsx",
		children: void 0,
		preloads: ["/assets/services.dental.whitening-DHGY0Zc1.js", "/assets/ServiceTemplate-BeykL8VT.js"]
	}
} });
//#endregion
export { tsrStartManifest };
