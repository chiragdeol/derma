globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as NodeResponse, i as defineLazyEventHandler, l as serve, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/.htaccess": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"e2-t0Yv7oS9aVebvvjYnJ+uVmn7Qzg\"",
		"mtime": "2026-06-24T11:42:11.624Z",
		"size": 226,
		"path": "../public/.htaccess"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"17-ZZkCVrbr4BSdjt/K43J0tq8+Qq4\"",
		"mtime": "2026-06-24T11:36:50.423Z",
		"size": 23,
		"path": "../public/robots.txt"
	},
	"/assets/about-DLNo5Oaj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1173-1+BU89lGnx9zOWmqudbNFcKqgYM\"",
		"mtime": "2026-07-09T06:51:31.672Z",
		"size": 4467,
		"path": "../public/assets/about-DLNo5Oaj.js"
	},
	"/assets/after-BnwPPy0P.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"54-MXIM7sJj1PRhhqwYQp0OIzw19uM\"",
		"mtime": "2026-07-09T06:51:31.673Z",
		"size": 84,
		"path": "../public/assets/after-BnwPPy0P.js"
	},
	"/assets/about-DCa5XqUK.jpg": {
		"type": "image/jpeg",
		"etag": "\"19971-0M/253wbtmX/eA6m258DcfQHLEI\"",
		"mtime": "2026-07-09T06:51:31.689Z",
		"size": 104817,
		"path": "../public/assets/about-DCa5XqUK.jpg"
	},
	"/assets/aesthetic-CoO-wpNT.jpg": {
		"type": "image/jpeg",
		"etag": "\"158ae-+BkUtuUdvZpMXTAt/wAsNfcTKkg\"",
		"mtime": "2026-07-09T06:51:31.690Z",
		"size": 88238,
		"path": "../public/assets/aesthetic-CoO-wpNT.jpg"
	},
	"/assets/contact-CJIktK6i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10e7-u1/Di2ELjP0NVbhUkcV8VW+JQOk\"",
		"mtime": "2026-07-09T06:51:31.674Z",
		"size": 4327,
		"path": "../public/assets/contact-CJIktK6i.js"
	},
	"/assets/after-DDWHdL6G.jpg": {
		"type": "image/jpeg",
		"etag": "\"1270f-/mboFu6ixBpBVYNg5ATrRAmzvc0\"",
		"mtime": "2026-07-09T06:51:31.691Z",
		"size": 75535,
		"path": "../public/assets/after-DDWHdL6G.jpg"
	},
	"/assets/before-CIDES9EB.jpg": {
		"type": "image/jpeg",
		"etag": "\"12579-0l4zXztZwOOgtXqk5hRZkJ7Cm1E\"",
		"mtime": "2026-07-09T06:51:31.692Z",
		"size": 75129,
		"path": "../public/assets/before-CIDES9EB.jpg"
	},
	"/assets/doctor-1-Dko9X97V.jpg": {
		"type": "image/jpeg",
		"etag": "\"c3e3-8ma8FWmwpAOmrVfanduXq/dNKHI\"",
		"mtime": "2026-07-09T06:51:31.693Z",
		"size": 50147,
		"path": "../public/assets/doctor-1-Dko9X97V.jpg"
	},
	"/assets/doctor-2-fssWe7B1.jpg": {
		"type": "image/jpeg",
		"etag": "\"c84b-CfxFpmMtfsLL4BHz6UbwlyEv/NQ\"",
		"mtime": "2026-07-09T06:51:31.695Z",
		"size": 51275,
		"path": "../public/assets/doctor-2-fssWe7B1.jpg"
	},
	"/assets/doctor-3-DD_j19KX.jpg": {
		"type": "image/jpeg",
		"etag": "\"d210-EXAiwNLQvPodYetJgbIQRUOz+vE\"",
		"mtime": "2026-07-09T06:51:31.696Z",
		"size": 53776,
		"path": "../public/assets/doctor-3-DD_j19KX.jpg"
	},
	"/assets/interior-CeRkam6M.jpg": {
		"type": "image/jpeg",
		"etag": "\"18d19-vIUu4swswJZnPT+xu5qFugP7RZk\"",
		"mtime": "2026-07-09T06:51:31.698Z",
		"size": 101657,
		"path": "../public/assets/interior-CeRkam6M.jpg"
	},
	"/assets/index-CvumA9ol.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5922b-aAi9L/loE08oadh9M7XYaBQayqo\"",
		"mtime": "2026-07-09T06:51:31.670Z",
		"size": 365099,
		"path": "../public/assets/index-CvumA9ol.js"
	},
	"/assets/hero-Dx1IkhrS.jpg": {
		"type": "image/jpeg",
		"etag": "\"1eea2-X3v+yRSaZSvk6pUYN4acIfD6cmg\"",
		"mtime": "2026-07-09T06:51:31.697Z",
		"size": 126626,
		"path": "../public/assets/hero-Dx1IkhrS.jpg"
	},
	"/assets/jsx-runtime-bzQ4Vb5N.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20d8-vMfP+4a4ykIjbw4InHkj3E5HWt0\"",
		"mtime": "2026-07-09T06:51:31.675Z",
		"size": 8408,
		"path": "../public/assets/jsx-runtime-bzQ4Vb5N.js"
	},
	"/assets/routes-CF_liunw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8371-eCtx/64nF3NOJi91STFE/CgtqpM\"",
		"mtime": "2026-07-09T06:51:31.676Z",
		"size": 33649,
		"path": "../public/assets/routes-CF_liunw.js"
	},
	"/assets/service-injectables-D2ndW2N5.jpg": {
		"type": "image/jpeg",
		"etag": "\"1198e-gZjWNwCZWY85rreLLBAOIs5nZH8\"",
		"mtime": "2026-07-09T06:51:31.699Z",
		"size": 72078,
		"path": "../public/assets/service-injectables-D2ndW2N5.jpg"
	},
	"/assets/service-laser-DYBNHqgC.jpg": {
		"type": "image/jpeg",
		"etag": "\"16def-WIGsPxAG47Fp27d49hzSTFA8cug\"",
		"mtime": "2026-07-09T06:51:31.700Z",
		"size": 93679,
		"path": "../public/assets/service-laser-DYBNHqgC.jpg"
	},
	"/assets/services-DKsgce_X.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d-YgkTFCDSkrOo/gTnmEdaoM43yDQ\"",
		"mtime": "2026-07-09T06:51:31.677Z",
		"size": 141,
		"path": "../public/assets/services-DKsgce_X.js"
	},
	"/assets/service-lifting-CPxv_i3P.jpg": {
		"type": "image/jpeg",
		"etag": "\"1609c-pqgZ4V5z7Zll4hV6WLZcMJN0RG0\"",
		"mtime": "2026-07-09T06:51:31.700Z",
		"size": 90268,
		"path": "../public/assets/service-lifting-CPxv_i3P.jpg"
	},
	"/assets/services.aesthetic-CO_Vy2qh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1409-73XTF8QslA1SJqLYPg/yNiuHpEg\"",
		"mtime": "2026-07-09T06:51:31.678Z",
		"size": 5129,
		"path": "../public/assets/services.aesthetic-CO_Vy2qh.js"
	},
	"/assets/service-surgery-2JHGVFHC.jpg": {
		"type": "image/jpeg",
		"etag": "\"149d5-U1ymVG3zpan26AOcpEsyG0wC+fk\"",
		"mtime": "2026-07-09T06:51:31.703Z",
		"size": 84437,
		"path": "../public/assets/service-surgery-2JHGVFHC.jpg"
	},
	"/assets/service-skin-D5jAfU_J.jpg": {
		"type": "image/jpeg",
		"etag": "\"1007f-LW9oVqFTGkWNQQBRl6Be2djDlzY\"",
		"mtime": "2026-07-09T06:51:31.702Z",
		"size": 65663,
		"path": "../public/assets/service-skin-D5jAfU_J.jpg"
	},
	"/logo-al-nemah.png": {
		"type": "image/png",
		"etag": "\"b5c92-8zwM5mRFUvIOLFaIwBVDfRB/m2M\"",
		"mtime": "2026-07-01T07:52:16.460Z",
		"size": 744594,
		"path": "../public/logo-al-nemah.png"
	},
	"/assets/services.dental.cosmetic-dentistry-DAescyuo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"873-mcXWrblixVGfMZMEMAFNQAWxllE\"",
		"mtime": "2026-07-09T06:51:31.678Z",
		"size": 2163,
		"path": "../public/assets/services.dental.cosmetic-dentistry-DAescyuo.js"
	},
	"/assets/services.dental.implants-Ck3DQevi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"851-3pFenAuxmVLZ0uTjyDxCpXuyz5Q\"",
		"mtime": "2026-07-09T06:51:31.680Z",
		"size": 2129,
		"path": "../public/assets/services.dental.implants-Ck3DQevi.js"
	},
	"/assets/services.dental.general-CrsQgxtV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8c4-wTWgTMIbt9E+/Tq6mDNjFSIDFh8\"",
		"mtime": "2026-07-09T06:51:31.679Z",
		"size": 2244,
		"path": "../public/assets/services.dental.general-CrsQgxtV.js"
	},
	"/assets/services.dental.orthodontics-BoSf57OP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"86d-YFVlOPyCv1Nj+NWdm+l6jcJdLhU\"",
		"mtime": "2026-07-09T06:51:31.681Z",
		"size": 2157,
		"path": "../public/assets/services.dental.orthodontics-BoSf57OP.js"
	},
	"/assets/services.dental.whitening-DHGY0Zc1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7a5-lqI2dfdC9oGzmYQ1LXEQdCqEhl8\"",
		"mtime": "2026-07-09T06:51:31.681Z",
		"size": 1957,
		"path": "../public/assets/services.dental.whitening-DHGY0Zc1.js"
	},
	"/assets/services.index-B83JEIHa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"aa6-sfx8T5Z7yylIfFZikv4vbUVrpA0\"",
		"mtime": "2026-07-09T06:51:31.682Z",
		"size": 2726,
		"path": "../public/assets/services.index-B83JEIHa.js"
	},
	"/assets/services.laser-Bm0qYciM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8c1-3zJBKJgW92T3gSyapXawoD97gj0\"",
		"mtime": "2026-07-09T06:51:31.684Z",
		"size": 2241,
		"path": "../public/assets/services.laser-Bm0qYciM.js"
	},
	"/assets/services.injectables-CpaQbeLz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8a7-3Ued5qfFj4lhH4hjhNI15fOEE3g\"",
		"mtime": "2026-07-09T06:51:31.683Z",
		"size": 2215,
		"path": "../public/assets/services.injectables-CpaQbeLz.js"
	},
	"/assets/services.lifting-B4k3wV_d.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"860-RfrHI9VvPpFEk+BCmBOPIA1w0p4\"",
		"mtime": "2026-07-09T06:51:31.685Z",
		"size": 2144,
		"path": "../public/assets/services.lifting-B4k3wV_d.js"
	},
	"/assets/services.surgery-B14ID3s9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"889-+aEUB9HpDDLedcoU0YqelW+BVLQ\"",
		"mtime": "2026-07-09T06:51:31.687Z",
		"size": 2185,
		"path": "../public/assets/services.surgery-B14ID3s9.js"
	},
	"/assets/services.skin-BMIgoIbA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dc9-zxLztiMja8tcCm8gXV7Lp79v9O8\"",
		"mtime": "2026-07-09T06:51:31.686Z",
		"size": 3529,
		"path": "../public/assets/services.skin-BMIgoIbA.js"
	},
	"/assets/services.wellness-ChHMwvIQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12f1-ibQssV6XkFecsSJbub2FLlmpkR4\"",
		"mtime": "2026-07-09T06:51:31.688Z",
		"size": 4849,
		"path": "../public/assets/services.wellness-ChHMwvIQ.js"
	},
	"/assets/ServiceTemplate-BeykL8VT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3cbc-ECdvZi7nnsRqchhtJNu/erHHaok\"",
		"mtime": "2026-07-09T06:51:31.671Z",
		"size": 15548,
		"path": "../public/assets/ServiceTemplate-BeykL8VT.js"
	},
	"/assets/styles-Ca5VUjYV.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1823a-zGVFdJn5uSOpjcNj/WCt0poYoMQ\"",
		"mtime": "2026-07-09T06:51:31.704Z",
		"size": 98874,
		"path": "../public/assets/styles-Ca5VUjYV.css"
	},
	"/assets/treatment-room-BitRXQsG.jpg": {
		"type": "image/jpeg",
		"etag": "\"ee42-KMKg+EGt55PEZNQEPzehU70zHZM\"",
		"mtime": "2026-07-09T06:51:31.705Z",
		"size": 60994,
		"path": "../public/assets/treatment-room-BitRXQsG.jpg"
	},
	"/assets/treatment-hands-CtGiHxsA.jpg": {
		"type": "image/jpeg",
		"etag": "\"12836-v8l5nvRxsV2AkpK2dI4cxM+67OE\"",
		"mtime": "2026-07-09T06:51:31.705Z",
		"size": 75830,
		"path": "../public/assets/treatment-hands-CtGiHxsA.jpg"
	},
	"/assets/wellness-muUuGTPe.jpg": {
		"type": "image/jpeg",
		"etag": "\"17075-3rvjqPPphR7nHAbEjkkVey/8mes\"",
		"mtime": "2026-07-09T06:51:31.707Z",
		"size": 94325,
		"path": "../public/assets/wellness-muUuGTPe.jpg"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_7H2IuH = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_7H2IuH
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
