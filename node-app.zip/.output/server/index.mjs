globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as NodeResponse, i as defineLazyEventHandler, l as serve, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/.htaccess": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"e2-t0Yv7oS9aVebvvjYnJ+uVmn7Qzg\"",
		"mtime": "2026-06-24T11:42:11.624Z",
		"size": 226,
		"path": "../public/.htaccess"
	},
	"/assets/about-D3Q_ZM5d.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11a6-Fv1K/xnFph07EejQzRmevnOC+RM\"",
		"mtime": "2026-07-01T06:33:18.827Z",
		"size": 4518,
		"path": "../public/assets/about-D3Q_ZM5d.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"17-ZZkCVrbr4BSdjt/K43J0tq8+Qq4\"",
		"mtime": "2026-06-24T11:36:50.423Z",
		"size": 23,
		"path": "../public/robots.txt"
	},
	"/assets/aesthetic-CoO-wpNT.jpg": {
		"type": "image/jpeg",
		"etag": "\"158ae-+BkUtuUdvZpMXTAt/wAsNfcTKkg\"",
		"mtime": "2026-07-01T06:33:18.837Z",
		"size": 88238,
		"path": "../public/assets/aesthetic-CoO-wpNT.jpg"
	},
	"/assets/after-DDWHdL6G.jpg": {
		"type": "image/jpeg",
		"etag": "\"1270f-/mboFu6ixBpBVYNg5ATrRAmzvc0\"",
		"mtime": "2026-07-01T06:33:18.837Z",
		"size": 75535,
		"path": "../public/assets/after-DDWHdL6G.jpg"
	},
	"/assets/about-DCa5XqUK.jpg": {
		"type": "image/jpeg",
		"etag": "\"19971-0M/253wbtmX/eA6m258DcfQHLEI\"",
		"mtime": "2026-07-01T06:33:18.836Z",
		"size": 104817,
		"path": "../public/assets/about-DCa5XqUK.jpg"
	},
	"/assets/before-CIDES9EB.jpg": {
		"type": "image/jpeg",
		"etag": "\"12579-0l4zXztZwOOgtXqk5hRZkJ7Cm1E\"",
		"mtime": "2026-07-01T06:33:18.838Z",
		"size": 75129,
		"path": "../public/assets/before-CIDES9EB.jpg"
	},
	"/assets/contact-BORLu2zZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10e1-68QCQHm2FE8ZMU4cG8hzemAWz44\"",
		"mtime": "2026-07-01T06:33:18.829Z",
		"size": 4321,
		"path": "../public/assets/contact-BORLu2zZ.js"
	},
	"/assets/doctor-1-Dko9X97V.jpg": {
		"type": "image/jpeg",
		"etag": "\"c3e3-8ma8FWmwpAOmrVfanduXq/dNKHI\"",
		"mtime": "2026-07-01T06:33:18.838Z",
		"size": 50147,
		"path": "../public/assets/doctor-1-Dko9X97V.jpg"
	},
	"/assets/interior-DJnF7DZT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"35-UBFJt1rVhZ7Kz/6r5myw1SDDcMY\"",
		"mtime": "2026-07-01T06:33:18.830Z",
		"size": 53,
		"path": "../public/assets/interior-DJnF7DZT.js"
	},
	"/assets/doctor-3-DD_j19KX.jpg": {
		"type": "image/jpeg",
		"etag": "\"d210-EXAiwNLQvPodYetJgbIQRUOz+vE\"",
		"mtime": "2026-07-01T06:33:18.838Z",
		"size": 53776,
		"path": "../public/assets/doctor-3-DD_j19KX.jpg"
	},
	"/assets/doctor-2-fssWe7B1.jpg": {
		"type": "image/jpeg",
		"etag": "\"c84b-CfxFpmMtfsLL4BHz6UbwlyEv/NQ\"",
		"mtime": "2026-07-01T06:33:18.838Z",
		"size": 51275,
		"path": "../public/assets/doctor-2-fssWe7B1.jpg"
	},
	"/assets/jsx-runtime-bzQ4Vb5N.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20d8-vMfP+4a4ykIjbw4InHkj3E5HWt0\"",
		"mtime": "2026-07-01T06:33:18.831Z",
		"size": 8408,
		"path": "../public/assets/jsx-runtime-bzQ4Vb5N.js"
	},
	"/assets/routes-DSfbT7Xi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5dfb-hGnzxcor3sbR6RyZYHX6Bh0L8Vo\"",
		"mtime": "2026-07-01T06:33:18.831Z",
		"size": 24059,
		"path": "../public/assets/routes-DSfbT7Xi.js"
	},
	"/assets/hero-Dx1IkhrS.jpg": {
		"type": "image/jpeg",
		"etag": "\"1eea2-X3v+yRSaZSvk6pUYN4acIfD6cmg\"",
		"mtime": "2026-07-01T06:33:18.839Z",
		"size": 126626,
		"path": "../public/assets/hero-Dx1IkhrS.jpg"
	},
	"/assets/interior-CeRkam6M.jpg": {
		"type": "image/jpeg",
		"etag": "\"18d19-vIUu4swswJZnPT+xu5qFugP7RZk\"",
		"mtime": "2026-07-01T06:33:18.839Z",
		"size": 101657,
		"path": "../public/assets/interior-CeRkam6M.jpg"
	},
	"/assets/service-injectables-D2ndW2N5.jpg": {
		"type": "image/jpeg",
		"etag": "\"1198e-gZjWNwCZWY85rreLLBAOIs5nZH8\"",
		"mtime": "2026-07-01T06:33:18.839Z",
		"size": 72078,
		"path": "../public/assets/service-injectables-D2ndW2N5.jpg"
	},
	"/assets/service-laser-DYBNHqgC.jpg": {
		"type": "image/jpeg",
		"etag": "\"16def-WIGsPxAG47Fp27d49hzSTFA8cug\"",
		"mtime": "2026-07-01T06:33:18.840Z",
		"size": 93679,
		"path": "../public/assets/service-laser-DYBNHqgC.jpg"
	},
	"/assets/service-lifting-CPxv_i3P.jpg": {
		"type": "image/jpeg",
		"etag": "\"1609c-pqgZ4V5z7Zll4hV6WLZcMJN0RG0\"",
		"mtime": "2026-07-01T06:33:18.840Z",
		"size": 90268,
		"path": "../public/assets/service-lifting-CPxv_i3P.jpg"
	},
	"/assets/index-DeLSDDrZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"57be3-Jkjqt0qVpZeQ4O0y5Bnao6BTPKA\"",
		"mtime": "2026-07-01T06:33:18.825Z",
		"size": 359395,
		"path": "../public/assets/index-DeLSDDrZ.js"
	},
	"/assets/service-surgery-2JHGVFHC.jpg": {
		"type": "image/jpeg",
		"etag": "\"149d5-U1ymVG3zpan26AOcpEsyG0wC+fk\"",
		"mtime": "2026-07-01T06:33:18.841Z",
		"size": 84437,
		"path": "../public/assets/service-surgery-2JHGVFHC.jpg"
	},
	"/assets/service-skin-D5jAfU_J.jpg": {
		"type": "image/jpeg",
		"etag": "\"1007f-LW9oVqFTGkWNQQBRl6Be2djDlzY\"",
		"mtime": "2026-07-01T06:33:18.841Z",
		"size": 65663,
		"path": "../public/assets/service-skin-D5jAfU_J.jpg"
	},
	"/assets/services-Dd_HQuxi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d-xKo5QiY1RDvf+5v9zXqMOcT8fqs\"",
		"mtime": "2026-07-01T06:33:18.832Z",
		"size": 141,
		"path": "../public/assets/services-Dd_HQuxi.js"
	},
	"/assets/services.aesthetic-CsS3dMU8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1409-x0T+3N6y+6JzEpl9x9FW9/XrLEw\"",
		"mtime": "2026-07-01T06:33:18.833Z",
		"size": 5129,
		"path": "../public/assets/services.aesthetic-CsS3dMU8.js"
	},
	"/assets/services.index-CH5xq8bC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a97-xBQL/+L2xVSIKZgyVAnqi2ymMJ8\"",
		"mtime": "2026-07-01T06:33:18.834Z",
		"size": 2711,
		"path": "../public/assets/services.index-CH5xq8bC.js"
	},
	"/assets/services.laser-B6pJ88it.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6ab-O4prscFOmdWDuRU6XQfj0Hs2VcM\"",
		"mtime": "2026-07-01T06:33:18.835Z",
		"size": 1707,
		"path": "../public/assets/services.laser-B6pJ88it.js"
	},
	"/assets/ServiceTemplate-mIwyP2QS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d3c-yUkQHo2lRHJCRBFikRD7f5vEMKg\"",
		"mtime": "2026-07-01T06:33:18.826Z",
		"size": 7484,
		"path": "../public/assets/ServiceTemplate-mIwyP2QS.js"
	},
	"/assets/services.lifting-CUlVBfvw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"666-Orp7w6fnWP/nogegsI6KowRzpz8\"",
		"mtime": "2026-07-01T06:33:18.835Z",
		"size": 1638,
		"path": "../public/assets/services.lifting-CUlVBfvw.js"
	},
	"/assets/services.injectables-DvXt4EcO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6cb-P+r0P/W7oZhqlhwodESM4ghsJEw\"",
		"mtime": "2026-07-01T06:33:18.834Z",
		"size": 1739,
		"path": "../public/assets/services.injectables-DvXt4EcO.js"
	},
	"/assets/services.wellness-CJZ7xBa-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12f1-MzraTDxdzpdar8MJZ2ClfPCxvno\"",
		"mtime": "2026-07-01T06:33:18.836Z",
		"size": 4849,
		"path": "../public/assets/services.wellness-CJZ7xBa-.js"
	},
	"/assets/services.skin-BlYq-TY2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"69c-vzZlcOI/7MfAjHoB8UQ7GUKggpE\"",
		"mtime": "2026-07-01T06:33:18.836Z",
		"size": 1692,
		"path": "../public/assets/services.skin-BlYq-TY2.js"
	},
	"/assets/styles-gIacCpfP.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1609e-lblILUUTIVKxHgBLnOpFosUpYEg\"",
		"mtime": "2026-07-01T06:33:18.842Z",
		"size": 90270,
		"path": "../public/assets/styles-gIacCpfP.css"
	},
	"/assets/services.surgery-D70FJIrN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"724-7XabgHxbT8nIsRX7rvgE+Fq2PYU\"",
		"mtime": "2026-07-01T06:33:18.836Z",
		"size": 1828,
		"path": "../public/assets/services.surgery-D70FJIrN.js"
	},
	"/assets/wellness-muUuGTPe.jpg": {
		"type": "image/jpeg",
		"etag": "\"17075-3rvjqPPphR7nHAbEjkkVey/8mes\"",
		"mtime": "2026-07-01T06:33:18.843Z",
		"size": 94325,
		"path": "../public/assets/wellness-muUuGTPe.jpg"
	},
	"/assets/treatment-room-BitRXQsG.jpg": {
		"type": "image/jpeg",
		"etag": "\"ee42-KMKg+EGt55PEZNQEPzehU70zHZM\"",
		"mtime": "2026-07-01T06:33:18.843Z",
		"size": 60994,
		"path": "../public/assets/treatment-room-BitRXQsG.jpg"
	},
	"/assets/treatment-hands-CtGiHxsA.jpg": {
		"type": "image/jpeg",
		"etag": "\"12836-v8l5nvRxsV2AkpK2dI4cxM+67OE\"",
		"mtime": "2026-07-01T06:33:18.842Z",
		"size": 75830,
		"path": "../public/assets/treatment-hands-CtGiHxsA.jpg"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_7H2IuH = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_7H2IuH
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
