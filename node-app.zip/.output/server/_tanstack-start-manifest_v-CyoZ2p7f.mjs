//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CyoZ2p7f.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/contact",
			"/services"
		],
		preloads: ["/assets/index-DeLSDDrZ.js", "/assets/jsx-runtime-bzQ4Vb5N.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DeLSDDrZ.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DSfbT7Xi.js", "/assets/interior-DJnF7DZT.js"]
	},
	"/about": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-D3Q_ZM5d.js", "/assets/interior-DJnF7DZT.js"]
	},
	"/contact": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-BORLu2zZ.js"]
	},
	"/services": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.tsx",
		children: [
			"/services/aesthetic",
			"/services/injectables",
			"/services/laser",
			"/services/lifting",
			"/services/skin",
			"/services/surgery",
			"/services/wellness",
			"/services/"
		],
		preloads: ["/assets/services-Dd_HQuxi.js"]
	},
	"/services/aesthetic": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.aesthetic.tsx",
		children: void 0,
		preloads: ["/assets/services.aesthetic-CsS3dMU8.js"]
	},
	"/services/injectables": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.injectables.tsx",
		children: void 0,
		preloads: ["/assets/services.injectables-DvXt4EcO.js", "/assets/ServiceTemplate-mIwyP2QS.js"]
	},
	"/services/laser": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.laser.tsx",
		children: void 0,
		preloads: ["/assets/services.laser-B6pJ88it.js", "/assets/ServiceTemplate-mIwyP2QS.js"]
	},
	"/services/lifting": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.lifting.tsx",
		children: void 0,
		preloads: ["/assets/services.lifting-CUlVBfvw.js", "/assets/ServiceTemplate-mIwyP2QS.js"]
	},
	"/services/skin": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.skin.tsx",
		children: void 0,
		preloads: ["/assets/services.skin-BlYq-TY2.js", "/assets/ServiceTemplate-mIwyP2QS.js"]
	},
	"/services/surgery": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.surgery.tsx",
		children: void 0,
		preloads: ["/assets/services.surgery-D70FJIrN.js", "/assets/ServiceTemplate-mIwyP2QS.js"]
	},
	"/services/wellness": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.wellness.tsx",
		children: void 0,
		preloads: ["/assets/services.wellness-CJZ7xBa-.js"]
	},
	"/services/": {
		filePath: "C:/Users/Boxinall/Downloads/seline-experience-main/seline-experience-main/src/routes/services.index.tsx",
		children: void 0,
		preloads: ["/assets/services.index-CH5xq8bC.js"]
	}
} });
//#endregion
export { tsrStartManifest };
