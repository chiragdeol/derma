import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as aesthetic_default } from "./aesthetic-DwgQ_WhB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services.aesthetic-MzJCC5Tl.js
var import_jsx_runtime = require_jsx_runtime();
var treatments = [
	{
		name: "Bespoke injectables",
		body: "Conservative, anatomically-driven enhancement using premium hyaluronic acids and neuromodulators.",
		time: "30 – 60 min"
	},
	{
		name: "Signature Lumière facial",
		body: "A multi-layer protocol combining cleansing, exfoliation, peptides and LED therapy.",
		time: "75 min"
	},
	{
		name: "Laser & light",
		body: "Fractional and pigment-specific lasers for tone, texture and clarity.",
		time: "45 – 90 min"
	},
	{
		name: "Skin boosters & polynucleotides",
		body: "Micro-injected hydration and regeneration for visible glow within days.",
		time: "30 min"
	},
	{
		name: "Chemical peels",
		body: "Customised acid blends to refine, brighten and even the complexion.",
		time: "45 min"
	},
	{
		name: "Mesotherapy",
		body: "Vitamin and amino-acid cocktails delivered directly into the dermis.",
		time: "30 min"
	}
];
var journey = [
	{
		step: "Consultation",
		body: "An unhurried conversation about your goals, skin history and lifestyle."
	},
	{
		step: "Diagnosis",
		body: "Skin analysis with imaging and a clear, written treatment plan."
	},
	{
		step: "Treatment",
		body: "Performed exclusively by our medical team using premium devices."
	},
	{
		step: "Aftercare",
		body: "Personalised products, follow-ups and seasonal maintenance plans."
	}
];
function Aesthetic() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative h-[80svh] min-h-[560px] overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: aesthetic_default,
					alt: "Aesthetic medicine at Lumière Clinic",
					width: 1600,
					height: 1200,
					className: "absolute inset-0 h-full w-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-foreground/20 via-foreground/10 to-foreground/70" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 mx-auto flex h-full max-w-6xl flex-col items-start justify-end px-6 pb-20 lg:px-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow text-ivory/80 mb-5",
							children: "Service · 01"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "font-display text-5xl leading-[1.05] text-ivory md:text-7xl lg:text-[5.5rem]",
							children: ["Aesthetic ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
								className: "italic",
								children: "Medicine."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xl text-base text-ivory/85",
							children: "A measured, anatomical approach to enhancement — where less is almost always more."
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-7xl px-6 py-28 lg:px-10 lg:py-36",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-14 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-6",
						children: "The promise"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-4xl leading-tight md:text-5xl",
						children: ["Refinement, never ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
							className: "italic",
							children: "replacement."
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-7",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base leading-relaxed text-muted-foreground",
						children: "Our aesthetic protocols are built around the architecture of your face — restoring volume where time has taken it, softening where tension has built, and reawakening skin so it carries your expression with ease. The goal is never a different face. It is your face, rested."
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-secondary/50",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-6 py-28 lg:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-6",
						children: "Treatments"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-4xl md:text-5xl",
						children: "A considered menu"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-px overflow-hidden rounded-2xl bg-border/70 md:grid-cols-2 lg:grid-cols-3",
						children: treatments.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "bg-background p-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl",
									children: t.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-muted-foreground",
									children: t.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6 text-xs uppercase tracking-[0.28em] text-accent",
									children: t.time
								})
							]
						}, t.name))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-6 py-28 lg:px-10 lg:py-36",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow mb-6",
					children: "The journey"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl md:text-5xl",
					children: "Four unhurried steps"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-14 grid gap-12 md:grid-cols-2 lg:grid-cols-4",
					children: journey.map((j, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-5xl text-accent",
							children: String(i + 1).padStart(2, "0")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-6 font-display text-2xl",
							children: j.step
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted-foreground",
							children: j.body
						})
					] }, j.step))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-20 flex flex-wrap items-center justify-between gap-6 rounded-2xl bg-primary p-10 text-primary-foreground sm:p-14",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl md:text-4xl",
						children: "Ready to begin?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm opacity-80",
						children: "Consultations are private and complimentary."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/contact",
						className: "rounded-full bg-ivory px-7 py-3.5 text-sm font-medium text-foreground hover:opacity-90",
						children: "Book a consultation"
					})]
				})
			]
		})
	] });
}
//#endregion
export { Aesthetic as component };
