import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as treatment_hands_default } from "./treatment-hands-MfkAZU49.mjs";
import { t as ServiceTemplate } from "./ServiceTemplate-CSpspR7l.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services.dental.cosmetic-dentistry-BOpjS7j6.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceTemplate, {
	division: "Dental",
	divisionUrl: "/services",
	categoryName: "Cosmetic Dentistry & Veneers",
	eyebrow: "Dental · Cosmetic",
	metaTitle: "Veneers & Hollywood Smile in Sharjah — Al Nemah Dental",
	metaDesc: "Natural veneers, Hollywood smile makeovers and bonding in Sharjah with digital smile design. Fix chips, gaps and stains. Book a smile consultation.",
	h1: "Cosmetic Dentistry & Veneers in Sharjah",
	intro: "Transform your smile with natural-looking veneers and full makeovers — designed digitally so you approve the look before treatment begins.",
	highlights: [
		["Digital", "Smile design"],
		["10+ years", "Veneer lifespan"],
		["No downtime", "Most cases"]
	],
	concerns: [
		"Chipped teeth",
		"Gaps",
		"Discolouration",
		"Uneven shape",
		"Worn teeth"
	],
	txIntro: "Our cosmetic dentistry menu, from single fixes to a full smile makeover.",
	treatments: [
		{
			name: "Porcelain Veneers",
			body: "Custom-shaded shells that correct shape, colour and gaps.",
			tags: ["Shape", "Colour"],
			duration: "2–3 visits",
			price: "From AED 1,500 / tooth"
		},
		{
			name: "Hollywood Smile",
			body: "A full smile makeover, digitally designed and previewed.",
			tags: ["Full makeover", "Preview"],
			duration: "2–4 visits",
			price: "From AED 15,000"
		},
		{
			name: "Composite Bonding",
			body: "Quick, affordable repair of chips and small gaps.",
			tags: ["Chips", "Gaps"],
			duration: "1 visit",
			price: "From AED 500"
		},
		{
			name: "Digital Smile Design",
			body: "On-screen preview of your new smile before we start.",
			tags: ["Preview", "Planning"],
			duration: "1 visit",
			price: "Complimentary"
		}
	],
	faqs: [
		{
			question: "Do veneers look natural?",
			answer: "Yes — custom shading and shaping blend them with your smile."
		},
		{
			question: "How long do they last?",
			answer: "Porcelain veneers commonly last 10–15 years."
		},
		{
			question: "Is much tooth removed?",
			answer: "Only a minimal layer; we preserve natural tooth."
		}
	],
	related: [
		{
			slug: "/services/dental/whitening",
			label: "Teeth Whitening"
		},
		{
			slug: "/services/dental/implants",
			label: "Dental Implants"
		},
		{
			slug: "/services/dental/orthodontics",
			label: "Orthodontics"
		}
	],
	heroImage: treatment_hands_default,
	dental: true
});
//#endregion
export { SplitComponent as component };
