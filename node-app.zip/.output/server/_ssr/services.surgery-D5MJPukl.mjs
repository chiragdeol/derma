import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as service_surgery_default } from "./service-surgery-Dmievn9d.mjs";
import { t as ServiceTemplate } from "./ServiceTemplate-JigWVX2v.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services.surgery-D5MJPukl.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceTemplate, {
	heroImage: service_surgery_default,
	eyebrow: "Service · Surgery",
	titleLead: "Plastic",
	titleItalic: "Surgery.",
	heroSubtitle: "A small, board-certified surgical team — chosen for technique, ethics and a deep respect for natural proportion.",
	promiseTitleLead: "Considered. Conservative.",
	promiseTitleItalic: "Beautiful.",
	promiseBody: "We turn down more surgical requests than we accept. Every procedure follows multiple consultations, full medical work-up and a clear understanding of what surgery can — and cannot — change.",
	treatmentsTitle: "Surgical procedures",
	treatments: [
		{
			name: "Rhinoplasty",
			body: "Open and preservation techniques tailored to ethnic anatomy.",
			time: "Surgical"
		},
		{
			name: "Blepharoplasty",
			body: "Upper and lower eyelid surgery to refresh the eyes.",
			time: "Surgical"
		},
		{
			name: "Liposuction & VASER",
			body: "Body contouring with ultrasound-assisted precision.",
			time: "Surgical"
		},
		{
			name: "Breast surgery",
			body: "Augmentation, reduction and lift, planned around proportion.",
			time: "Surgical"
		},
		{
			name: "Mommy makeover",
			body: "Combined abdominoplasty and breast restoration after childbirth.",
			time: "Surgical"
		},
		{
			name: "Facelift / deep-plane",
			body: "Long-lasting structural rejuvenation for advanced laxity.",
			time: "Surgical"
		}
	],
	journey: [
		{
			step: "Consultation",
			body: "Two unhurried sessions before any surgical decision."
		},
		{
			step: "Work-up",
			body: "Full bloods, imaging and anaesthetic clearance."
		},
		{
			step: "Surgery",
			body: "Performed in a licensed, accredited hospital setting."
		},
		{
			step: "Recovery",
			body: "Concierge aftercare, lymphatic drainage and follow-ups."
		}
	],
	ctaTitle: "Request a surgical consultation",
	ctaBody: "All surgical enquiries are reviewed personally by our medical director."
});
//#endregion
export { SplitComponent as component };
