//#region node_modules/.nitro/vite/services/ssr/assets/wellness-BF4dqQWl.js
var wellness_default = "/assets/wellness-muUuGTPe.jpg";
//#endregion
export { wellness_default as t };
