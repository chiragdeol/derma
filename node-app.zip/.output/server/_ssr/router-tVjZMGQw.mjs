import { r as __toESM } from "../_runtime.mjs";
import { t as about_default } from "./about-D1gCRPDi.mjs";
import { n as require_jsx_runtime, r as require_react, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { M as useRouter, c as HeadContent, d as Outlet, f as lazyRouteComponent, h as Link, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as service_injectables_default } from "./service-injectables-Bk16S-vI.mjs";
import { t as service_skin_default } from "./service-skin-Dzrbnfhw.mjs";
import { t as service_laser_default } from "./service-laser-DmmFyV4a.mjs";
import { t as service_lifting_default } from "./service-lifting-Dr5OfZM1.mjs";
import { t as service_surgery_default } from "./service-surgery-Dmievn9d.mjs";
import { t as wellness_default } from "./wellness-BF4dqQWl.mjs";
import { t as hero_default } from "./hero-Dvd-gcVk.mjs";
import { t as aesthetic_default } from "./aesthetic-DwgQ_WhB.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { a as MapPin, c as Ghost, i as MessageCircle, l as ChevronDown, n as Send, o as Linkedin, r as Phone, s as Instagram, t as Youtube } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-tVjZMGQw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-gIacCpfP.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
var simpleNav = [
	{
		to: "/about",
		label: "The Clinic"
	},
	{
		to: "/#doctors",
		label: "Doctors"
	},
	{
		to: "/#results",
		label: "Results"
	},
	{
		to: "/#offers",
		label: "Offers"
	}
];
var serviceLinks = [
	{
		to: "/services/injectables",
		title: "Cosmetic Injectables",
		desc: "Botox, fillers & Profhilo",
		image: service_injectables_default
	},
	{
		to: "/services/skin",
		title: "Skin & HydraFacial",
		desc: "Medical-grade facials & peels",
		image: service_skin_default
	},
	{
		to: "/services/laser",
		title: "Laser & Hair Removal",
		desc: "Multi-wavelength platforms",
		image: service_laser_default
	},
	{
		to: "/services/lifting",
		title: "Anti-Aging & Lifting",
		desc: "Morpheus8, threads & Ultherapy",
		image: service_lifting_default
	},
	{
		to: "/services/surgery",
		title: "Plastic Surgery",
		desc: "Board-certified surgeons",
		image: service_surgery_default
	},
	{
		to: "/services/wellness",
		title: "Wellness & Longevity",
		desc: "IV drips & hormone health",
		image: wellness_default
	}
];
function Header() {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [servicesOpen, setServicesOpen] = (0, import_react.useState)(false);
	const servicesTimer = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 20);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	const openServices = () => {
		if (servicesTimer.current) clearTimeout(servicesTimer.current);
		setServicesOpen(true);
	};
	const closeServices = () => {
		servicesTimer.current = setTimeout(() => setServicesOpen(false), 180);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: `fixed inset-x-0 top-0 z-50 transition-all duration-500 ${scrolled ? "bg-background/95 backdrop-blur-md border-b border-border/60 shadow-sm" : "bg-background/90 backdrop-blur-sm border-b border-border/40"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-primary text-ivory text-[11px] py-1.5 px-6 lg:px-10 flex flex-col sm:flex-row justify-between items-center gap-1.5 transition-all duration-300",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5 opacity-90 tracking-wide font-light",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Jumeirah Beach Road, Dubai" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "opacity-45",
							children: "•"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Open daily 10am–10pm" })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-4 opacity-90 font-light",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "tel:+97140000000",
							className: "hover:underline tracking-wide",
							children: "+971 4 000 0000"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "opacity-30",
							children: "/"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-accent",
									children: "EN"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "opacity-30",
									children: "/"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hover:underline cursor-pointer opacity-70",
									children: "العربية"
								})
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "group flex flex-col items-start leading-none gap-0.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-2xl tracking-[0.05em] uppercase text-foreground",
							children: "Lumière"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[0.6rem] uppercase tracking-[0.25em] text-muted-foreground pl-0.5",
							children: "clinic · dubai"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "hidden items-center gap-8 lg:flex",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							onMouseEnter: openServices,
							onMouseLeave: closeServices,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: `inline-flex items-center gap-1 text-sm tracking-wide transition-colors ${servicesOpen ? "text-foreground font-medium" : "text-foreground/80 hover:text-foreground"}`,
								children: ["Treatments", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `h-3.5 w-3.5 transition-transform duration-200 ${servicesOpen ? "rotate-180" : ""}` })]
							}), servicesOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute top-full left-1/2 mt-5 w-[720px] -translate-x-1/2 overflow-hidden rounded-2xl border border-border bg-background shadow-2xl",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-3 gap-4",
										children: serviceLinks.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: s.to,
											className: "group block overflow-hidden rounded-xl",
											onClick: () => setServicesOpen(false),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "overflow-hidden rounded-xl",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
													src: s.image,
													alt: s.title,
													className: "aspect-[4/3] w-full object-cover transition-transform duration-700 group-hover:scale-105",
													width: 280,
													height: 210
												})
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm font-medium text-foreground",
													children: s.title
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-0.5 text-xs text-muted-foreground",
													children: s.desc
												})]
											})]
										}, s.to))
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-5 border-t border-border/40 pt-4 text-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/services",
											className: "inline-flex items-center text-sm font-medium text-foreground underline-offset-8 hover:underline",
											onClick: () => setServicesOpen(false),
											children: "View all services →"
										})
									})]
								})
							})]
						}), simpleNav.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: n.to,
							className: "text-sm tracking-wide text-foreground/80 transition-colors hover:text-foreground",
							activeProps: { className: "text-foreground font-medium" },
							activeOptions: { exact: n.to === "/" },
							children: n.label
						}, n.to))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden items-center gap-4 lg:flex",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "tel:+97140000000",
							className: "rounded-lg border border-border px-5 py-2 text-sm font-medium text-foreground hover:bg-muted/50 transition-all",
							children: "Call"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://wa.me/971543251817",
							target: "_blank",
							rel: "noreferrer",
							className: "rounded-lg bg-primary px-5 py-2 text-sm font-medium text-primary-foreground hover:opacity-95 transition-all shadow-sm",
							children: "Book consultation"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setOpen((v) => !v),
						"aria-label": "Toggle menu",
						className: "lg:hidden text-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
							width: "26",
							height: "26",
							viewBox: "0 0 24 24",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "1.5",
							children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6 6l12 12M18 6L6 18" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M3 7h18" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M3 17h18" })] })
						})
					})
				]
			}),
			open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden border-t border-border/60 bg-background max-h-[80vh] overflow-y-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-1 px-6 py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-widest text-muted-foreground mt-2",
							children: "Menu"
						}),
						simpleNav.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: n.to,
							onClick: () => setOpen(false),
							className: "py-2 text-sm text-foreground/80 hover:text-foreground",
							children: n.label
						}, n.to)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs uppercase tracking-widest text-muted-foreground",
							children: "Treatments"
						}),
						serviceLinks.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: s.to,
							onClick: () => setOpen(false),
							className: "py-1.5 pl-2 text-sm text-foreground/70 hover:text-foreground",
							children: s.title
						}, s.to)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2 mt-4 pt-4 border-t border-border/40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "tel:+97140000000",
								className: "flex justify-center rounded-lg border border-border py-2.5 text-sm font-medium text-foreground",
								children: "Call"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "https://wa.me/971543251817",
								className: "flex justify-center rounded-lg bg-primary py-2.5 text-sm font-medium text-primary-foreground",
								children: "Book consultation"
							})]
						})
					]
				})
			})
		]
	});
}
var exploreLinks = [
	{
		to: "/about",
		label: "About Lumière"
	},
	{
		to: "/about",
		label: "Specialists"
	},
	{
		to: "/services",
		label: "Services"
	},
	{
		to: "/contact",
		label: "Contacts"
	},
	{
		to: "/about",
		label: "Our History"
	},
	{
		to: "/",
		label: "News"
	}
];
var aestheticLinks = [
	{
		to: "/services/injectables",
		label: "Cosmetic Injectables"
	},
	{
		to: "/services/skin",
		label: "Skin & HydraFacial"
	},
	{
		to: "/services/laser",
		label: "Laser & Hair Removal"
	},
	{
		to: "/services/lifting",
		label: "Anti-Aging & Lifting"
	}
];
var surgeryLinks = [
	{
		to: "/services/surgery",
		label: "Plastic Surgery"
	},
	{
		to: "/services/surgery",
		label: "Rhinoplasty"
	},
	{
		to: "/services/surgery",
		label: "Liposuction"
	},
	{
		to: "/services/surgery",
		label: "Blepharoplasty"
	}
];
var longevityLinks = [
	{
		to: "/services/wellness",
		label: "IV Drips"
	},
	{
		to: "/services/wellness",
		label: "Hormone Health"
	},
	{
		to: "/services/wellness",
		label: "Hair Restoration"
	},
	{
		to: "/services/wellness",
		label: "Skin Boosters"
	}
];
var socials = [
	{
		href: "https://wa.me/971543251817",
		label: "WhatsApp",
		Icon: MessageCircle
	},
	{
		href: "https://instagram.com",
		label: "Instagram",
		Icon: Instagram
	},
	{
		href: "https://linkedin.com",
		label: "LinkedIn",
		Icon: Linkedin
	},
	{
		href: "https://t.me",
		label: "Telegram",
		Icon: Send
	},
	{
		href: "https://youtube.com",
		label: "YouTube",
		Icon: Youtube
	},
	{
		href: "https://snapchat.com",
		label: "Snapchat",
		Icon: Ghost
	}
];
function FooterColumn({ title, links }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-5 text-sm font-medium tracking-wide text-ivory",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-3 text-sm",
		children: links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: l.to,
			className: "text-ivory/70 transition-colors hover:text-ivory",
			children: l.label
		}) }, l.label))
	})] });
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "mt-32 bg-[#3a3a36] text-ivory",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-6 py-20 lg:px-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-12 lg:grid-cols-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:col-span-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							className: "inline-flex items-balumiere gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-5xl italic text-ivory",
								children: "Lumière"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[0.65rem] uppercase tracking-[0.32em] text-ivory/70",
								children: "clinic"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-3 text-sm",
							children: exploreLinks.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: l.to,
								className: "text-ivory transition-colors hover:text-ivory/70",
								children: l.label
							}) }, l.label))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterColumn, {
							title: "Aesthetic Medicine",
							links: aestheticLinks
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:col-span-2 space-y-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterColumn, {
							title: "Plastic Surgery",
							links: surgeryLinks
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:col-span-3 space-y-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterColumn, {
							title: "Precision Longevity",
							links: longevityLinks
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-16 grid gap-12 border-t border-ivory/15 pt-12 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7 space-y-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap items-center gap-4",
						children: socials.map(({ href, label, Icon }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href,
							target: "_blank",
							rel: "noreferrer",
							"aria-label": label,
							className: "flex h-11 w-11 items-center justify-center rounded-full border border-ivory/30 text-ivory transition-colors hover:bg-ivory hover:text-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
						}, label))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "tel:+971800735463",
								className: "block text-ivory underline-offset-4 hover:underline",
								children: "+971 800 735 463"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "mailto:hello@lumiere.ae",
								className: "block text-ivory underline-offset-4 hover:underline",
								children: "hello@lumiere.ae"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "pt-2 text-ivory/70",
								children: "Jumeirah Beach Road, Dubai, United Arab Emirates"
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5 flex flex-col gap-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/contact",
						className: "inline-flex items-center justify-center gap-2 rounded-full border border-ivory/40 px-7 py-4 text-sm font-medium text-ivory transition-colors hover:bg-ivory hover:text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-4 w-4" }), "Request a Call"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "https://maps.google.com/?q=Jumeirah+Beach+Road+Dubai",
						target: "_blank",
						rel: "noreferrer",
						className: "inline-flex items-center justify-center gap-2 rounded-full bg-ivory px-7 py-4 text-sm font-medium text-foreground transition-opacity hover:opacity-90",
						children: ["Interactive Map", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4 text-accent" })]
					})]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-ivory/15",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-7xl flex-col items-start justify-between gap-3 px-6 py-6 text-xs text-ivory/60 sm:flex-row sm:items-center lg:px-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#",
					className: "underline-offset-4 hover:underline",
					children: "Personal Data Processing Policy"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" Lumière Clinic. All rights reserved. M.O.H. Approval No2FXSIE1V-020725"
				] })]
			})
		})]
	});
}
function WhatsAppFab() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href: "https://wa.me/971543251817?text=Hello%20Lumière%20Clinic%2C%20I'd%20like%20to%20book%20a%20consultation.",
		target: "_blank",
		rel: "noreferrer",
		"aria-label": "Chat with us on WhatsApp",
		className: "fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-2xl ring-4 ring-[#25D366]/20 transition-transform hover:scale-110",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
			viewBox: "0 0 32 32",
			width: "28",
			height: "28",
			fill: "currentColor",
			"aria-hidden": "true",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M19.11 17.27c-.27-.14-1.6-.79-1.85-.88-.25-.09-.43-.14-.61.14-.18.27-.7.88-.86 1.06-.16.18-.32.2-.59.07-.27-.14-1.14-.42-2.17-1.34-.8-.71-1.34-1.59-1.5-1.86-.16-.27-.02-.41.12-.55.12-.12.27-.32.41-.48.14-.16.18-.27.27-.45.09-.18.05-.34-.02-.48-.07-.14-.61-1.47-.84-2.01-.22-.53-.45-.46-.61-.47-.16-.01-.34-.01-.52-.01s-.48.07-.73.34c-.25.27-.96.94-.96 2.29 0 1.35.98 2.65 1.12 2.83.14.18 1.94 2.96 4.71 4.15.66.28 1.17.45 1.57.58.66.21 1.26.18 1.73.11.53-.08 1.6-.65 1.83-1.28.23-.63.23-1.17.16-1.28-.07-.11-.25-.18-.52-.32zM16.02 5C9.94 5 5 9.94 5 16.02c0 1.95.51 3.85 1.48 5.51L5 27l5.62-1.46a10.97 10.97 0 0 0 5.4 1.4h.01c6.07 0 11.01-4.94 11.01-11.02 0-2.94-1.14-5.71-3.22-7.79A10.94 10.94 0 0 0 16.02 5zm0 20.06h-.01a9.13 9.13 0 0 1-4.65-1.27l-.33-.2-3.34.87.89-3.25-.22-.34a9.06 9.06 0 0 1-1.41-4.85c0-5.03 4.1-9.12 9.13-9.12 2.44 0 4.73.95 6.45 2.68a9.05 9.05 0 0 1 2.67 6.45c0 5.03-4.09 9.13-9.13 9.13z" })
		})
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow mb-4",
					children: "Error 404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-6xl text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90",
						children: "Return home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "rounded-full border border-border bg-background px-5 py-2.5 text-sm font-medium text-foreground hover:bg-accent/20",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$12 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Lumière Clinic — Advanced Medicine meets Aesthetic Artistry" },
			{
				name: "description",
				content: "Lumière Clinic, Dubai: multidisciplinary aesthetic, plastic surgery and wellness center delivering natural, refined results."
			},
			{
				property: "og:title",
				content: "Lumière Clinic"
			},
			{
				property: "og:description",
				content: "Where advanced medicine meets aesthetic artistry."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;1,400&family=Inter:wght@300;400;500;600&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$12.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "pt-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppFab, {})
		]
	});
}
var $$splitComponentImporter$11 = () => import("./services-C5swur1F.mjs");
var Route$11 = createFileRoute("/services")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./contact-DqXLycTI.mjs");
var Route$10 = createFileRoute("/contact")({
	head: () => ({ meta: [
		{ title: "Contact — Lumière Clinic Dubai" },
		{
			name: "description",
			content: "Book a consultation or visit Lumière Clinic in Dubai. Get in touch by WhatsApp, phone or our private inquiry form."
		},
		{
			property: "og:title",
			content: "Contact Lumière Clinic"
		},
		{
			property: "og:description",
			content: "Book a consultation or visit our Dubai clinic."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./about-CgxTjhH2.mjs");
var Route$9 = createFileRoute("/about")({
	head: () => ({ meta: [
		{ title: "About — Lumière Clinic" },
		{
			name: "description",
			content: "Discover Lumière Clinic: our philosophy, our team and the multidisciplinary approach behind every transformation."
		},
		{
			property: "og:title",
			content: "About Lumière Clinic"
		},
		{
			property: "og:description",
			content: "A multidisciplinary team united by craft, science and care."
		},
		{
			property: "og:image",
			content: about_default
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./routes-VAlHPW5Q.mjs");
var Route$8 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "Lumière Clinic — Where Advanced Medicine Meets Aesthetic Artistry" },
		{
			name: "description",
			content: "Thoughtfully designed aesthetic, plastic surgery and wellness treatments in Dubai. Natural, refined results from a multidisciplinary clinic."
		},
		{
			property: "og:title",
			content: "Lumière Clinic"
		},
		{
			property: "og:description",
			content: "Where advanced medicine meets aesthetic artistry."
		},
		{
			property: "og:image",
			content: hero_default
		},
		{
			name: "twitter:image",
			content: hero_default
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./services.index-4IYCXq3b.mjs");
var Route$7 = createFileRoute("/services/")({
	head: () => ({ meta: [
		{ title: "Services — Lumière Clinic Dubai" },
		{
			name: "description",
			content: "Dermatology, injectables, laser, lifting, plastic surgery and wellness — six disciplines under one Dubai roof."
		},
		{
			property: "og:title",
			content: "Services at Lumière Clinic"
		},
		{
			property: "og:description",
			content: "Six disciplines under one roof, led by board-certified doctors."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./services.wellness-BwVzW26S.mjs");
var Route$6 = createFileRoute("/services/wellness")({
	head: () => ({ meta: [
		{ title: "Wellness & Recovery — Lumière Clinic" },
		{
			name: "description",
			content: "IV therapy, lymphatic drainage, longevity and body sculpting programs at Lumière Clinic — restore balance from within."
		},
		{
			property: "og:title",
			content: "Wellness at Lumière"
		},
		{
			property: "og:description",
			content: "Holistic wellness, recovery and longevity programs."
		},
		{
			property: "og:image",
			content: wellness_default
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./services.surgery-D5MJPukl.mjs");
var Route$5 = createFileRoute("/services/surgery")({
	head: () => ({ meta: [
		{ title: "Plastic Surgery — Lumière Clinic Dubai" },
		{
			name: "description",
			content: "Rhinoplasty, liposuction, eyelid surgery and breast procedures by board-certified plastic surgeons in Dubai."
		},
		{
			property: "og:title",
			content: "Plastic Surgery at Lumière"
		},
		{
			property: "og:description",
			content: "Board-certified surgeons for considered, beautifully natural results."
		},
		{
			property: "og:image",
			content: service_surgery_default
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./services.skin-hwBoyMOB.mjs");
var Route$4 = createFileRoute("/services/skin")({
	head: () => ({ meta: [
		{ title: "Skin & HydraFacial — Lumière Clinic Dubai" },
		{
			name: "description",
			content: "Medical-grade facials, HydraFacial, mesotherapy, peels and microneedling for clear, luminous skin."
		},
		{
			property: "og:title",
			content: "Skin & HydraFacial at Lumière"
		},
		{
			property: "og:description",
			content: "Resurfacing and hydration protocols for visibly better skin."
		},
		{
			property: "og:image",
			content: service_skin_default
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./services.lifting-CE4pULOE.mjs");
var Route$3 = createFileRoute("/services/lifting")({
	head: () => ({ meta: [
		{ title: "Anti-Aging & Lifting — Lumière Clinic Dubai" },
		{
			name: "description",
			content: "Morpheus8, Ultherapy, PDO threads and Fotona 4D — non-surgical tightening and collagen renewal."
		},
		{
			property: "og:title",
			content: "Anti-Aging at Lumière"
		},
		{
			property: "og:description",
			content: "Non-surgical lifting for visible firmness and contour."
		},
		{
			property: "og:image",
			content: service_lifting_default
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./services.laser-BFLnMqef.mjs");
var Route$2 = createFileRoute("/services/laser")({
	head: () => ({ meta: [
		{ title: "Laser & Hair Removal — Lumière Clinic Dubai" },
		{
			name: "description",
			content: "Advanced laser platforms for hair removal, pigmentation, vascular lesions and tattoo removal — safe for all skin types."
		},
		{
			property: "og:title",
			content: "Laser at Lumière"
		},
		{
			property: "og:description",
			content: "Diode, Nd:YAG and Pico lasers performed by trained physicians."
		},
		{
			property: "og:image",
			content: service_laser_default
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./services.injectables-bh1AUHJ7.mjs");
var Route$1 = createFileRoute("/services/injectables")({
	head: () => ({ meta: [
		{ title: "Cosmetic Injectables — Lumière Clinic Dubai" },
		{
			name: "description",
			content: "Botox, dermal fillers, Profhilo and lip enhancement performed by medical doctors. Subtle, anatomical results."
		},
		{
			property: "og:title",
			content: "Cosmetic Injectables at Lumière"
		},
		{
			property: "og:description",
			content: "Anatomical injectables for natural, refined expression."
		},
		{
			property: "og:image",
			content: service_injectables_default
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./services.aesthetic-MzJCC5Tl.mjs");
var Route = createFileRoute("/services/aesthetic")({
	head: () => ({ meta: [
		{ title: "Aesthetic Medicine — Lumière Clinic" },
		{
			name: "description",
			content: "Injectables, advanced facials, laser and skin rejuvenation at Lumière Clinic Dubai — natural, lasting results."
		},
		{
			property: "og:title",
			content: "Aesthetic Medicine at Lumière"
		},
		{
			property: "og:description",
			content: "Bespoke aesthetic treatments designed for natural harmony."
		},
		{
			property: "og:image",
			content: aesthetic_default
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var ServicesRoute = Route$11.update({
	id: "/services",
	path: "/services",
	getParentRoute: () => Route$12
});
var ContactRoute = Route$10.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$12
});
var AboutRoute = Route$9.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$12
});
var IndexRoute = Route$8.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$12
});
var ServicesIndexRoute = Route$7.update({
	id: "/",
	path: "/",
	getParentRoute: () => ServicesRoute
});
var ServicesWellnessRoute = Route$6.update({
	id: "/wellness",
	path: "/wellness",
	getParentRoute: () => ServicesRoute
});
var ServicesSurgeryRoute = Route$5.update({
	id: "/surgery",
	path: "/surgery",
	getParentRoute: () => ServicesRoute
});
var ServicesSkinRoute = Route$4.update({
	id: "/skin",
	path: "/skin",
	getParentRoute: () => ServicesRoute
});
var ServicesLiftingRoute = Route$3.update({
	id: "/lifting",
	path: "/lifting",
	getParentRoute: () => ServicesRoute
});
var ServicesLaserRoute = Route$2.update({
	id: "/laser",
	path: "/laser",
	getParentRoute: () => ServicesRoute
});
var ServicesInjectablesRoute = Route$1.update({
	id: "/injectables",
	path: "/injectables",
	getParentRoute: () => ServicesRoute
});
var ServicesRouteChildren = {
	ServicesAestheticRoute: Route.update({
		id: "/aesthetic",
		path: "/aesthetic",
		getParentRoute: () => ServicesRoute
	}),
	ServicesInjectablesRoute,
	ServicesLaserRoute,
	ServicesLiftingRoute,
	ServicesSkinRoute,
	ServicesSurgeryRoute,
	ServicesWellnessRoute,
	ServicesIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AboutRoute,
	ContactRoute,
	ServicesRoute: ServicesRoute._addFileChildren(ServicesRouteChildren)
};
var routeTree = Route$12._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0,
		basepath: "/dermo"
	});
};
//#endregion
export { getRouter };
