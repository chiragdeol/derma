//#region node_modules/.nitro/vite/services/ssr/assets/service-lifting-Dr5OfZM1.js
var service_lifting_default = "/assets/service-lifting-CPxv_i3P.jpg";
//#endregion
export { service_lifting_default as t };
