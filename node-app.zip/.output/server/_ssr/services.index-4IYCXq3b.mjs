import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as service_injectables_default } from "./service-injectables-Bk16S-vI.mjs";
import { t as service_skin_default } from "./service-skin-Dzrbnfhw.mjs";
import { t as service_laser_default } from "./service-laser-DmmFyV4a.mjs";
import { t as service_lifting_default } from "./service-lifting-Dr5OfZM1.mjs";
import { t as service_surgery_default } from "./service-surgery-Dmievn9d.mjs";
import { t as wellness_default } from "./wellness-BF4dqQWl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services.index-4IYCXq3b.js
var import_jsx_runtime = require_jsx_runtime();
var services = [
	{
		num: "01",
		to: "/services/injectables",
		title: "Cosmetic Injectables",
		body: "Botox, fillers, Profhilo and lip enhancement — subtle, anatomical results.",
		image: service_injectables_default
	},
	{
		num: "02",
		to: "/services/skin",
		title: "Skin & HydraFacial",
		body: "Medical-grade facials, peels and resurfacing for luminous skin.",
		image: service_skin_default
	},
	{
		num: "03",
		to: "/services/laser",
		title: "Laser & Hair Removal",
		body: "Multi-wavelength laser platforms safe across all skin types.",
		image: service_laser_default
	},
	{
		num: "04",
		to: "/services/lifting",
		title: "Anti-Aging & Lifting",
		body: "Morpheus8, Ultherapy, threads and Fotona 4D for non-surgical lift.",
		image: service_lifting_default
	},
	{
		num: "05",
		to: "/services/surgery",
		title: "Plastic Surgery",
		body: "Board-certified surgeons for considered, beautifully natural results.",
		image: service_surgery_default
	},
	{
		num: "06",
		to: "/services/wellness",
		title: "Wellness & Longevity",
		body: "IV drips, hormone health, hair restoration and skin boosters.",
		image: wellness_default
	}
];
function ServicesIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-secondary/30 pt-36 pb-20 lg:pt-48 lg:pb-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-6 lg:px-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow mb-6",
					children: "Our services"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "font-display text-5xl leading-[1.05] md:text-6xl lg:text-7xl",
					children: ["Six disciplines, ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
						className: "italic",
						children: "one philosophy."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 max-w-xl text-base leading-relaxed text-muted-foreground",
					children: "From a single HydraFacial to a full surgical plan, every Lumière service follows the same standard: physician-led, evidence-based, and quietly luxurious."
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mx-auto max-w-7xl px-6 py-24 lg:px-10 lg:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-10 sm:grid-cols-2 lg:grid-cols-3",
			children: services.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: s.to,
				className: "group block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-hidden rounded-2xl bg-card",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: s.image,
						alt: s.title,
						loading: "lazy",
						width: 1024,
						height: 1024,
						className: "aspect-[4/5] w-full object-cover transition-transform duration-[1200ms] group-hover:scale-105"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow text-muted-foreground",
							children: s.num
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-3xl text-foreground",
							children: s.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted-foreground",
							children: s.body
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-5 inline-flex items-center text-sm text-foreground underline-offset-8 group-hover:underline",
							children: "Explore →"
						})
					]
				})]
			}, s.num))
		})
	})] });
}
//#endregion
export { ServicesIndex as component };
