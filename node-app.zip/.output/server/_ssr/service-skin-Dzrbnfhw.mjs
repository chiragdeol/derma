//#region node_modules/.nitro/vite/services/ssr/assets/service-skin-Dzrbnfhw.js
var service_skin_default = "/assets/service-skin-D5jAfU_J.jpg";
//#endregion
export { service_skin_default as t };
