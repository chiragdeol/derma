//#region node_modules/.nitro/vite/services/ssr/assets/aesthetic-DwgQ_WhB.js
var aesthetic_default = "/assets/aesthetic-CoO-wpNT.jpg";
//#endregion
export { aesthetic_default as t };
