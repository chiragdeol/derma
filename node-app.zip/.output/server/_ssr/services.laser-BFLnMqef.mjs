import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as service_laser_default } from "./service-laser-DmmFyV4a.mjs";
import { t as ServiceTemplate } from "./ServiceTemplate-JigWVX2v.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services.laser-BFLnMqef.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceTemplate, {
	heroImage: service_laser_default,
	eyebrow: "Service · Laser",
	titleLead: "Laser &",
	titleItalic: "Hair Removal.",
	heroSubtitle: "Medical-grade laser platforms — calibrated for every Fitzpatrick skin type, performed by dermatology-trained practitioners.",
	promiseTitleLead: "Right device, right",
	promiseTitleItalic: "settings.",
	promiseBody: "We invest in multi-wavelength platforms so the laser fits the skin — not the other way around. That is what makes treatment effective on darker, Middle-Eastern and South-Asian skin without burns or hypopigmentation.",
	treatmentsTitle: "Laser treatments",
	treatments: [
		{
			name: "Diode hair removal",
			body: "Fast, comfortable full-body sessions — safe for all skin types.",
			time: "30 – 90 min"
		},
		{
			name: "Pigmentation & melasma",
			body: "Pico-toning for sun damage, freckles and stubborn pigmentation.",
			time: "30 min"
		},
		{
			name: "Vascular lasers",
			body: "Targets redness, broken capillaries and rosacea.",
			time: "30 min"
		},
		{
			name: "Tattoo removal",
			body: "Pico-laser for high clearance with fewer sessions.",
			time: "20 – 45 min"
		},
		{
			name: "Fractional resurfacing",
			body: "CO₂ and erbium for scars, pores and overall texture.",
			time: "60 min"
		},
		{
			name: "Laser carbon peel",
			body: "Instant glow, refined pores and minor pigmentation.",
			time: "30 min"
		}
	],
	journey: [
		{
			step: "Patch test",
			body: "Always, before the first treatment."
		},
		{
			step: "Plan",
			body: "Realistic session count and seasonal scheduling."
		},
		{
			step: "Session",
			body: "Cooling, comfort and licensed-physician oversight."
		},
		{
			step: "Aftercare",
			body: "SPF, recovery balms and clear lifestyle guidance."
		}
	]
});
//#endregion
export { SplitComponent as component };
