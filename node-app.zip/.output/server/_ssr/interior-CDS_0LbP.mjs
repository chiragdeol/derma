//#region node_modules/.nitro/vite/services/ssr/assets/interior-CDS_0LbP.js
var interior_default = "/assets/interior-CeRkam6M.jpg";
//#endregion
export { interior_default as t };
