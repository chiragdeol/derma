//#region node_modules/.nitro/vite/services/ssr/assets/service-laser-DmmFyV4a.js
var service_laser_default = "/assets/service-laser-DYBNHqgC.jpg";
//#endregion
export { service_laser_default as t };
