//#region node_modules/.nitro/vite/services/ssr/assets/hero-Dvd-gcVk.js
var hero_default = "/assets/hero-Dx1IkhrS.jpg";
//#endregion
export { hero_default as t };
