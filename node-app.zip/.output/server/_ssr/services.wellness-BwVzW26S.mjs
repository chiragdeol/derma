import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as wellness_default } from "./wellness-BF4dqQWl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services.wellness-BwVzW26S.js
var import_jsx_runtime = require_jsx_runtime();
var programs = [
	{
		name: "IV nutrient therapy",
		body: "Tailored intravenous blends for energy, immunity, recovery or radiance.",
		time: "45 min"
	},
	{
		name: "Lymphatic drainage",
		body: "A specialised manual technique to reduce inflammation and sculpt contours.",
		time: "60 min"
	},
	{
		name: "Longevity assessment",
		body: "Comprehensive biomarker panel, body composition and a personalised plan.",
		time: "120 min"
	},
	{
		name: "Body sculpting",
		body: "Non-invasive radiofrequency, cryolipolysis and EMS technologies.",
		time: "45 – 60 min"
	},
	{
		name: "Sleep & stress reset",
		body: "Multi-modal sessions combining breathwork, red light and craniosacral therapy.",
		time: "75 min"
	},
	{
		name: "Postpartum recovery",
		body: "A gentle protocol for tissue, hormones and energy after childbirth.",
		time: "package"
	}
];
function Wellness() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative h-[80svh] min-h-[560px] overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: wellness_default,
					alt: "Wellness treatment room",
					width: 1600,
					height: 1200,
					className: "absolute inset-0 h-full w-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-foreground/20 via-foreground/10 to-foreground/70" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 mx-auto flex h-full max-w-6xl flex-col items-start justify-end px-6 pb-20 lg:px-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow text-ivory/80 mb-5",
							children: "Service · 02"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "font-display text-5xl leading-[1.05] text-ivory md:text-7xl lg:text-[5.5rem]",
							children: ["Wellness & ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
								className: "italic",
								children: "Recovery."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xl text-base text-ivory/85",
							children: "Programs that restore balance from within — for energy, longevity and a body that feels like home."
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-7xl px-6 py-28 lg:px-10 lg:py-36",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-14 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-6",
						children: "The approach"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-4xl leading-tight md:text-5xl",
						children: ["Outside reflects ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
							className: "italic",
							children: "inside."
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-7",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base leading-relaxed text-muted-foreground",
						children: "Lasting beauty depends on what is happening beneath the skin. Our wellness programs are built on diagnostics — sleep, stress, hormones, micronutrients — so every treatment serves a longer arc of vitality, not just a single appointment."
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-secondary/50",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-6 py-28 lg:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-6",
						children: "Programs"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-4xl md:text-5xl",
						children: "For energy, calm and longevity"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-px overflow-hidden rounded-2xl bg-border/70 md:grid-cols-2 lg:grid-cols-3",
						children: programs.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "bg-background p-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl",
									children: p.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-muted-foreground",
									children: p.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6 text-xs uppercase tracking-[0.28em] text-accent",
									children: p.time
								})
							]
						}, p.name))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-7xl px-6 py-28 lg:px-10 lg:py-36",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-16 lg:grid-cols-2 lg:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-5",
						children: "Membership"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-4xl leading-tight md:text-5xl",
						children: ["The Lumière ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
							className: "italic",
							children: "circle."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-base leading-relaxed text-muted-foreground",
						children: "A year-long program of seasonal assessments, monthly therapies and direct access to our medical team — designed for clients who treat wellbeing as a long practice."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/contact",
						className: "mt-10 inline-flex rounded-full bg-primary px-7 py-3.5 text-sm font-medium text-primary-foreground hover:opacity-90",
						children: "Request information"
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-2xl border border-border bg-card p-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-5 text-sm",
						children: [
							"Quarterly biomarker panel",
							"Monthly signature therapy",
							"Priority booking",
							"Personal wellness advisor",
							"Seasonal home protocols"
						].map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-foreground/85",
								children: b
							})]
						}, b))
					})
				})]
			})
		})
	] });
}
//#endregion
export { Wellness as component };
