//#region node_modules/.nitro/vite/services/ssr/assets/service-surgery-Dmievn9d.js
var service_surgery_default = "/assets/service-surgery-2JHGVFHC.jpg";
//#endregion
export { service_surgery_default as t };
