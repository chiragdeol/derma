import { r as __toESM } from "../_runtime.mjs";
import { t as interior_default } from "./interior-CDS_0LbP.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as before_default, t as after_default } from "./after-CDzrgEUI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ServiceTemplate-CSpspR7l.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FAQItemComponent = ({ question, answer }) => {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b border-border/60",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			onClick: () => setOpen(!open),
			className: "w-full flex justify-between items-center text-left py-5 font-display text-lg text-foreground cursor-pointer group",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: question }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `text-[#d2a960] text-xl transition-transform duration-300 ${open ? "rotate-45" : ""}`,
				children: "+"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `overflow-hidden transition-all duration-300 ${open ? "max-h-[300px] pb-5" : "max-h-0"}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground/95 leading-relaxed max-w-3xl",
				children: answer
			})
		})]
	});
};
function BeforeAfterSection({ treatments }) {
	const [activeTreatment, setActiveTreatment] = (0, import_react.useState)(treatments[0]?.name || "");
	const [position, setPosition] = (0, import_react.useState)(50);
	const containerRef = (0, import_react.useRef)(null);
	const isDragging = (0, import_react.useRef)(false);
	const handleMove = (clientX) => {
		if (!containerRef.current) return;
		const rect = containerRef.current.getBoundingClientRect();
		const x = clientX - rect.left;
		setPosition(Math.max(0, Math.min(100, x / rect.width * 100)));
	};
	const handleMouseUp = () => {
		isDragging.current = false;
	};
	(0, import_react.useEffect)(() => {
		window.addEventListener("mouseup", handleMouseUp);
		window.addEventListener("touchend", handleMouseUp);
		return () => {
			window.removeEventListener("mouseup", handleMouseUp);
			window.removeEventListener("touchend", handleMouseUp);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "py-20 bg-card border-y border-border/60",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-6 lg:px-10 grid gap-12 lg:grid-cols-[1.1fr_0.9fr] items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: containerRef,
				onMouseDown: (e) => {
					isDragging.current = true;
					handleMove(e.clientX);
				},
				onTouchStart: (e) => {
					isDragging.current = true;
					handleMove(e.touches[0].clientX);
				},
				onMouseMove: (e) => {
					if (isDragging.current) handleMove(e.clientX);
				},
				onTouchMove: (e) => {
					if (isDragging.current) handleMove(e.touches[0].clientX);
				},
				className: "relative w-full aspect-[4/3] rounded-xl overflow-hidden border border-border select-none cursor-ew-resize shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-0 flex items-end justify-end p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: after_default,
							alt: "After treatment",
							className: "absolute inset-0 w-full h-full object-cover pointer-events-none"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "relative z-10 text-[10px] uppercase tracking-wider font-semibold text-white bg-black/45 px-3 py-1.5 rounded",
							children: "After"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: { clipPath: `inset(0 ${100 - position}% 0 0)` },
						className: "absolute inset-0 flex items-end justify-start p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: before_default,
							alt: "Before treatment",
							className: "absolute inset-0 w-full h-full object-cover pointer-events-none"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "relative z-10 text-[10px] uppercase tracking-wider font-semibold text-white bg-black/45 px-3 py-1.5 rounded",
							children: "Before"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute left-4 top-4 font-display italic text-xs text-white bg-black/40 px-3 py-1.5 rounded shadow",
						children: activeTreatment
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: { left: `${position}%` },
						className: "absolute top-0 bottom-0 w-0.5 bg-[#d2a960] -translate-x-1/2 pointer-events-none",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-card border border-[#d2a960] shadow-md flex items-center justify-center text-[#d2a960] font-bold text-xs select-none",
							children: "⇆"
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-4",
						children: "Real results"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl md:text-4xl text-foreground mb-4",
						children: "See the difference."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base text-muted-foreground/95 leading-relaxed mb-6",
						children: "Every result is a real Al Nemah patient, shared with written consent. Drag the handle to compare — and pick a treatment below."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display italic text-sm text-muted-foreground/80 mb-4",
						children: "Slide to reveal before & after"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2 flex-wrap",
						children: treatments.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setActiveTreatment(t.name),
							className: `text-xs px-4 py-2 rounded-full border transition-all duration-300 font-sans cursor-pointer ${activeTreatment === t.name ? "border-[#d2a960] text-primary bg-background font-medium" : "border-border/80 text-muted-foreground hover:border-[#d2a960]/60"}`,
							children: t.name
						}, t.name))
					})
				]
			})]
		})
	});
}
function ServiceTemplate({ division, divisionUrl, categoryName, eyebrow, metaTitle, metaDesc, h1, intro, highlights, concerns, txIntro, treatments, faqs, related, heroImage, dental = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "border-b border-border/60 bg-card py-4 text-xs text-muted-foreground mt-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-6 lg:px-10 flex gap-2 items-center flex-wrap",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "hover:text-primary",
						children: "Home"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-primary/70",
						children: "›"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/services",
						className: "hover:text-primary",
						children: "Treatments"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-primary/70",
						children: "›"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: divisionUrl,
						className: "hover:text-primary",
						children: division
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-primary/70",
						children: "›"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground font-semibold",
						children: categoryName
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-12 md:py-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-6 lg:px-10 grid gap-12 lg:grid-cols-[1.1fr_0.9fr] items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-4",
						children: eyebrow
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-4xl md:text-5xl lg:text-6xl text-foreground mb-6 leading-tight",
						children: h1.includes("Sharjah") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [h1.replace("Sharjah", ""), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
							className: "italic text-[#d2a960] font-light",
							children: "Sharjah"
						})] }) : h1
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base md:text-lg text-muted-foreground/95 leading-relaxed max-w-xl mb-8",
						children: intro
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-4 flex-wrap mb-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://wa.me/971500999324",
							className: "rounded-lg bg-[#d2a960] text-black px-6 py-3.5 text-sm font-semibold hover:opacity-95 transition-all shadow-sm",
							children: "Book a consultation"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://wa.me/971500999324",
							className: "rounded-lg bg-[#1f6b53] px-6 py-3.5 text-sm font-semibold text-white hover:opacity-95 transition-all shadow-sm flex items-center gap-1.5",
							children: "WhatsApp us"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-6 pt-6 border-t border-border/70",
						children: highlights.map(([val, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-xl md:text-2xl text-foreground font-semibold",
								children: val
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] uppercase tracking-wider text-muted-foreground/80 mt-1",
								children: label
							})]
						}, label))
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-3 border border-[#d2a960]/30 rounded-2xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-hidden rounded-xl",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: heroImage,
								alt: categoryName,
								width: 800,
								height: 1e3,
								className: "aspect-[4/5] w-full object-cover transition-transform duration-700 hover:scale-102"
							})
						})
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "bg-card border-y border-border/50 py-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-6 lg:px-10 flex items-center gap-4 flex-wrap",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-semibold tracking-wider uppercase text-muted-foreground/90",
					children: "Concerns we treat"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2 flex-wrap",
					children: concerns.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs bg-background border border-border/80 px-3 py-1.5 rounded-full text-foreground/95",
						children: c
					}, c))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-20 lg:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-6 lg:px-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl mb-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "eyebrow mb-4",
							children: ["Treatments in ", categoryName]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-3xl md:text-4xl",
							children: [
								"Everything under ",
								categoryName,
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-base text-muted-foreground/90",
							children: txIntro
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col",
					children: treatments.map((t, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 lg:grid-cols-[1fr_1.05fr] gap-14 items-center py-16 border-t border-border/60 first:border-0 first:pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `relative ${idx % 2 === 1 ? "lg:order-2" : ""}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 border border-[#d2a960]/40 rounded-2xl relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "overflow-hidden rounded-xl aspect-[4/3] bg-gradient-to-br from-[#ECE0CF] to-[#B49E7E] flex items-end",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "m-4 text-[10px] italic font-display text-white bg-black/40 px-3 py-1.5 rounded",
										children: [t.name, " — treatment photo"]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute -right-3 top-8 bg-card border border-border/60 px-4 py-2.5 rounded-lg shadow-md z-10 flex flex-col items-start min-w-[100px]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
										className: "text-[9px] uppercase tracking-wider text-muted-foreground",
										children: "From"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
										className: "font-display text-base text-[#d2a960] mt-0.5",
										children: t.price.replace("From ", "")
									})]
								})]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-semibold tracking-widest text-[#d2a960] uppercase mb-3",
									children: ["Treatment 0", idx + 1]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl md:text-3xl text-foreground mb-3",
									children: t.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm md:text-base text-muted-foreground/90 leading-relaxed mb-4 max-w-xl",
									children: t.body
								}),
								t.points && t.points.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-2 mb-6",
									children: t.points.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "relative pl-6 text-sm text-foreground/90",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "absolute left-0 text-[#d2a960] font-bold",
											children: "✓"
										}), p]
									}, p))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "flex gap-2 flex-wrap mb-6",
									children: t.tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "text-xs text-muted-foreground border border-border/85 px-2.5 py-1 rounded-full",
										children: tag
									}, tag))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex gap-6 flex-wrap py-4 border-y border-border/60 mb-6",
									children: t.duration.split("·").map((m) => {
										const parts = m.trim().split(" ");
										const val = parts[0] || "";
										const label = parts.slice(1).join(" ") || "Info";
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-col",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
												className: "font-display text-base text-foreground font-semibold",
												children: val
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
												className: "text-[10px] uppercase tracking-wider text-muted-foreground",
												children: label
											})]
										}, m);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-3 flex-wrap",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: "https://wa.me/971500999324",
										className: "rounded-lg bg-[#d2a960] text-black px-5 py-2.5 text-xs font-semibold hover:opacity-95 transition-all shadow-sm",
										children: ["Book ", t.name]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "https://wa.me/971500999324",
										className: "rounded-lg bg-[#1f6b53] px-5 py-2.5 text-xs font-semibold text-white hover:opacity-95 transition-all shadow-sm",
										children: "WhatsApp"
									})]
								})
							]
						})]
					}, t.name))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BeforeAfterSection, { treatments }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-20 bg-forest text-ivory",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-6 lg:px-10 grid gap-12 lg:grid-cols-2 items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-4 text-[#d2a960]",
						children: "Why Al Nemah"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl md:text-4xl text-white mb-8",
						children: "Care you can trust, results that look natural."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-t border-ivory/20 pt-5 flex gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-xl text-[#d2a960]",
									children: "01"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-lg text-white mb-1",
									children: "Doctor-led, always"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-ivory/70 leading-relaxed",
									children: "Every treatment is planned and performed by licensed specialists — never delegated."
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-t border-ivory/20 pt-5 flex gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-xl text-[#d2a960]",
									children: "02"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-lg text-white mb-1",
									children: "Honest recommendations"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-ivory/70 leading-relaxed",
									children: "We advise what you actually need, and talk you out of what you don't."
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-t border-ivory/20 pt-5 border-b border-ivory/20 pb-5 flex gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-xl text-[#d2a960]",
									children: "03"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-lg text-white mb-1",
									children: "MOH licensed"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-ivory/70 leading-relaxed",
									children: "A fully accredited, safety-first clinic in Sharjah."
								})] })]
							})
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-3 border border-ivory/30 rounded-2xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-hidden rounded-xl",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: interior_default,
								alt: "Al Nemah Clinic",
								className: "aspect-[4/3] w-full object-cover"
							})
						})
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-20 lg:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-6 lg:px-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl mb-12",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-4",
						children: "Good to know"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl md:text-4xl",
						children: "Frequently asked questions."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col",
					children: faqs.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FAQItemComponent, {
						question: f.question,
						answer: f.answer
					}, f.question))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "py-20 bg-card border-t border-border/60",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-6 lg:px-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-3",
						children: "Explore more"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl md:text-3xl",
						children: "Related categories."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-6 sm:grid-cols-3",
					children: related.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: r.slug,
						className: "block bg-background border border-border/60 hover:border-[#d2a960]/60 p-6 rounded-xl transition-all duration-300 hover:-translate-y-0.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] uppercase tracking-wider text-[#d2a960] font-semibold mb-2 block",
								children: "Explore Related"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-base text-foreground font-semibold mb-2",
								children: r.label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-semibold text-primary",
								children: "Explore →"
							})
						]
					}, r.slug))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-forest text-ivory py-16 text-center border-t border-ivory/15",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-4xl px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow text-[#d2a960] mb-4",
						children: "Ready when you are"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl md:text-4xl text-white mb-4",
						children: "Book your consultation."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-ivory/70 max-w-md mx-auto mb-8",
						children: "A specialist replies within 15 minutes during clinic hours — no pressure, just honest advice."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-4 justify-center flex-wrap",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://wa.me/971500999324",
							className: "rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-black hover:opacity-90 transition-all",
							children: "Book consultation"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "tel:+971500999324",
							className: "rounded-lg border border-ivory/30 px-6 py-3 text-sm font-semibold text-white hover:bg-white/10 transition-all",
							children: "Call the clinic"
						})]
					})
				]
			})
		})
	] });
}
//#endregion
export { ServiceTemplate as t };
