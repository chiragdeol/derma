//#region node_modules/.nitro/vite/services/ssr/assets/after-CDzrgEUI.js
var before_default = "/assets/before-CIDES9EB.jpg";
var after_default = "/assets/after-DDWHdL6G.jpg";
//#endregion
export { before_default as n, after_default as t };
