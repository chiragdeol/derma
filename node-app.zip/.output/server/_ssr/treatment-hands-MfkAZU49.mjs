//#region node_modules/.nitro/vite/services/ssr/assets/treatment-hands-MfkAZU49.js
var treatment_hands_default = "/assets/treatment-hands-CtGiHxsA.jpg";
//#endregion
export { treatment_hands_default as t };
