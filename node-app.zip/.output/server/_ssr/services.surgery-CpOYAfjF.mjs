import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as service_surgery_default } from "./service-surgery-Dmievn9d.mjs";
import { t as ServiceTemplate } from "./ServiceTemplate-CSpspR7l.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services.surgery-CpOYAfjF.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceTemplate, {
	division: "Dermatology & Aesthetics",
	divisionUrl: "/services",
	categoryName: "Plastic Surgery",
	eyebrow: "Surgery · Board-certified",
	metaTitle: "Plastic Surgery in Sharjah | Rhinoplasty & Body — Al Nemah",
	metaDesc: "Board-certified plastic surgery in Sharjah — rhinoplasty, liposuction, eyelid and breast surgery in an accredited facility. Book a surgical consultation.",
	h1: "Plastic Surgery in Sharjah",
	intro: "Board-certified surgeons delivering considered, beautifully natural results — in an accredited, fully supported environment.",
	highlights: [
		["Certified", "Surgeons"],
		["Accredited", "Facility"],
		["Full", "Aftercare"]
	],
	concerns: [
		"Nose shape",
		"Stubborn fat",
		"Hooded eyes",
		"Breast shape",
		"Facial balance"
	],
	txIntro: "Our surgical procedures, each beginning with an in-depth consultation.",
	treatments: [
		{
			name: "Rhinoplasty",
			body: "Nose reshaping for balance and easier breathing.",
			tags: ["Shape", "Function"],
			duration: "Surgery · 1–2 wk recovery",
			price: "On consultation"
		},
		{
			name: "Liposuction",
			body: "Targeted body contouring of stubborn fat.",
			tags: ["Contour", "Body"],
			duration: "Surgery · 1–2 wk recovery",
			price: "On consultation"
		},
		{
			name: "Blepharoplasty",
			body: "Eyelid surgery to refresh a tired, hooded look.",
			tags: ["Eyes", "Refresh"],
			duration: "Surgery · 1 wk recovery",
			price: "On consultation"
		},
		{
			name: "Breast Surgery",
			body: "Augmentation, reduction or lift for natural proportion.",
			tags: ["Shape", "Proportion"],
			duration: "Surgery · 2 wk recovery",
			price: "On consultation"
		}
	],
	faqs: [
		{
			question: "How do I know if I'm a candidate?",
			answer: "A consultation assesses your health, goals and expectations first."
		},
		{
			question: "What's recovery like?",
			answer: "Most procedures need 1–2 weeks before normal activity."
		},
		{
			question: "Will results look natural?",
			answer: "That's our priority — we plan around your features."
		}
	],
	related: [
		{
			slug: "/services/lifting",
			label: "Anti-Aging & Lifting"
		},
		{
			slug: "/services/injectables",
			label: "Cosmetic Injectables"
		},
		{
			slug: "/services/skin",
			label: "Skin & HydraFacial"
		}
	],
	heroImage: service_surgery_default,
	dental: false
});
//#endregion
export { SplitComponent as component };
