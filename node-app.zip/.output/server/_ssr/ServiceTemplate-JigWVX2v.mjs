import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ServiceTemplate-JigWVX2v.js
var import_jsx_runtime = require_jsx_runtime();
function ServiceTemplate({ eyebrow, titleLead, titleItalic, heroSubtitle, heroImage, promiseEyebrow = "The promise", promiseTitleLead, promiseTitleItalic, promiseBody, treatmentsTitle, treatments, journey, gallery, beforeAfter, ctaTitle = "Ready to begin?", ctaBody = "Consultations are private and complimentary." }) {
	const galleryItems = gallery ?? [
		{
			src: heroImage,
			caption: "Inside the treatment",
			alt: `${titleLead} ${titleItalic}`
		},
		{
			src: "/assets/treatment-hands-CtGiHxsA.jpg",
			caption: "Precision and care",
			alt: "Doctor performing aesthetic treatment"
		},
		{
			src: "/assets/treatment-room-BitRXQsG.jpg",
			caption: "Our private suites",
			alt: "Lumière treatment suite"
		},
		{
			src: "/assets/interior-CeRkam6M.jpg",
			caption: "The Lumière atelier",
			alt: "Lumière clinic interior"
		}
	];
	const baItems = beforeAfter ?? [{
		before: "/assets/before-CIDES9EB.jpg",
		after: "/assets/after-DDWHdL6G.jpg",
		label: "Skin clarity & glow",
		note: "Result shown after a personalised course of treatment."
	}];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative h-[80svh] min-h-[560px] overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: heroImage,
					alt: `${titleLead} ${titleItalic}`,
					width: 1600,
					height: 1200,
					className: "absolute inset-0 h-full w-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-foreground/20 via-foreground/10 to-foreground/70" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 mx-auto flex h-full max-w-6xl flex-col items-start justify-end px-6 pb-20 lg:px-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow text-ivory/80 mb-5",
							children: eyebrow
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "font-display text-5xl leading-[1.05] text-ivory md:text-7xl lg:text-[5.5rem]",
							children: [
								titleLead,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
									className: "italic",
									children: titleItalic
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xl text-base text-ivory/85",
							children: heroSubtitle
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-7xl px-6 py-28 lg:px-10 lg:py-36",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-14 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-6",
						children: promiseEyebrow
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-4xl leading-tight md:text-5xl",
						children: [
							promiseTitleLead,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
								className: "italic",
								children: promiseTitleItalic
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-7",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base leading-relaxed text-muted-foreground",
						children: promiseBody
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-background",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-6 pb-20 lg:px-10 lg:pb-24",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-10 flex items-end justify-between gap-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-4",
						children: "In the clinic"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl md:text-4xl",
						children: "A closer look"
					})] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4",
					children: galleryItems.slice(0, 4).map((g, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
						className: `group relative overflow-hidden rounded-xl ${i === 0 ? "col-span-2 row-span-2 aspect-square md:aspect-[4/5]" : "aspect-square"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: g.src,
							alt: g.alt ?? g.caption ?? "Lumière clinic",
							loading: "lazy",
							width: 800,
							height: 800,
							className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
						}), g.caption && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
							className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-foreground/70 to-transparent p-4 text-xs uppercase tracking-[0.22em] text-ivory",
							children: g.caption
						})]
					}, i))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-secondary/50",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-6 py-28 lg:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-6",
						children: "Treatments"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-4xl md:text-5xl",
						children: treatmentsTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-px overflow-hidden rounded-2xl bg-border/70 md:grid-cols-2 lg:grid-cols-3",
						children: treatments.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "bg-background p-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl",
									children: t.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-muted-foreground",
									children: t.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6 text-xs uppercase tracking-[0.28em] text-accent",
									children: t.time
								})
							]
						}, t.name))
					})
				]
			})
		}),
		journey && journey.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-6 py-28 lg:px-10 lg:py-36",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow mb-6",
					children: "The journey"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl md:text-5xl",
					children: "A considered process"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-14 grid gap-12 md:grid-cols-2 lg:grid-cols-4",
					children: journey.map((j, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-5xl text-accent",
							children: String(i + 1).padStart(2, "0")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-6 font-display text-2xl",
							children: j.step
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted-foreground",
							children: j.body
						})
					] }, j.step))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-secondary/40",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-6 py-28 lg:px-10 lg:py-32",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid items-end gap-10 lg:grid-cols-12",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:col-span-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow mb-5",
							children: "Before & after"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-4xl leading-tight md:text-5xl",
							children: [
								"Real change, ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
									className: "italic",
									children: "measured"
								}),
								" over time."
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:col-span-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-base leading-relaxed text-muted-foreground",
							children: "Every result is photographed under identical lighting at fixed intervals, so the change you see is the change you can trust — never filtered, never retouched."
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-14 grid gap-12",
					children: baItems.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-6 md:grid-cols-2 md:gap-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
								className: "relative overflow-hidden rounded-2xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: b.before,
									alt: `${b.label} — before`,
									loading: "lazy",
									width: 1024,
									height: 1024,
									className: "h-full w-full object-cover"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
									className: "absolute left-4 top-4 rounded-full bg-foreground/70 px-4 py-1.5 text-[11px] uppercase tracking-[0.28em] text-ivory",
									children: "Before"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
								className: "relative overflow-hidden rounded-2xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: b.after,
									alt: `${b.label} — after`,
									loading: "lazy",
									width: 1024,
									height: 1024,
									className: "h-full w-full object-cover"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
									className: "absolute left-4 top-4 rounded-full bg-accent px-4 py-1.5 text-[11px] uppercase tracking-[0.28em] text-accent-foreground",
									children: "After"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-2xl",
									children: b.label
								}), b.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted-foreground",
									children: b.note
								})]
							})
						]
					}, i))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-7xl px-6 py-28 lg:px-10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-6 rounded-2xl bg-primary p-10 text-primary-foreground sm:p-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl md:text-4xl",
					children: ctaTitle
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm opacity-80",
					children: ctaBody
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/contact",
					className: "rounded-full bg-ivory px-7 py-3.5 text-sm font-medium text-foreground hover:opacity-90",
					children: "Book a consultation"
				})]
			})
		})
	] });
}
//#endregion
export { ServiceTemplate as t };
