import { t as interior_default } from "./interior-CDS_0LbP.mjs";
import { t as about_default } from "./about-D1gCRPDi.mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-BnGvQZSG.js
var import_jsx_runtime = require_jsx_runtime();
var values = [
	{
		num: "01",
		title: "Craft",
		body: "Every treatment is approached as a work of detail and discipline."
	},
	{
		num: "02",
		title: "Science",
		body: "Evidence-based protocols, advanced devices and continuous research."
	},
	{
		num: "03",
		title: "Care",
		body: "An unhurried experience built around the person, not the procedure."
	},
	{
		num: "04",
		title: "Discretion",
		body: "A private, considered sanctuary in the heart of Sharjah."
	}
];
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-6 pt-40 pb-20 lg:px-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow mb-8",
					children: "About Al Nemah"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "font-display text-5xl leading-[1.05] md:text-7xl lg:text-[5.5rem]",
					children: [
						"A clinic built on ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
							className: "italic",
							children: "craft,"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"science and care."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-10 max-w-2xl text-lg leading-relaxed text-muted-foreground",
					children: "Al Nemah is a multidisciplinary aesthetic, laser and dental center where scientific expertise and a personalized approach help our clients improve their quality of life — from skin and silhouette to vitality and longevity."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "relative",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl gap-12 px-6 lg:grid-cols-12 lg:gap-16 lg:px-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden rounded-2xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: about_default,
							alt: "Portrait reflecting Al Nemah aesthetic",
							loading: "lazy",
							width: 1400,
							height: 1600,
							className: "aspect-[4/5] w-full object-cover"
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7 lg:pt-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow mb-5",
							children: "Our philosophy"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-4xl leading-tight md:text-5xl",
							children: ["Beauty supported by ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
								className: "italic",
								children: "medicine."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 space-y-6 text-base leading-relaxed text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We believe results should look effortless. That means choosing less when less is enough — and committing fully when more is needed. Our doctors collaborate across disciplines so each plan is considered from every angle." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The Al Nemah experience is calm by design: a long welcome, an honest consultation and a clear, gradual plan. We move at the pace of your skin, your body and your life." })]
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-6 py-28 lg:px-10 lg:py-40",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow mb-5",
					children: "What guides us"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl md:text-5xl",
					children: "Four quiet principles"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-px overflow-hidden rounded-2xl bg-border/70 md:grid-cols-2 lg:grid-cols-4",
				children: values.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-background p-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl text-accent",
							children: v.num
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-6 font-display text-2xl",
							children: v.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted-foreground",
							children: v.body
						})
					]
				}, v.num))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-secondary/50",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl gap-12 px-6 py-24 lg:grid-cols-2 lg:items-center lg:px-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-hidden rounded-2xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: interior_default,
						alt: "Treatment room at Al Nemah Clinic",
						loading: "lazy",
						width: 1600,
						height: 1200,
						className: "aspect-[5/4] w-full object-cover"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-5",
						children: "The team"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-4xl leading-tight md:text-5xl",
						children: "Doctors, therapists and artisans of detail."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-base leading-relaxed text-muted-foreground",
						children: "Our practitioners are selected for both technical mastery and their bedside presence. Many trained across Europe and the Middle East, and all share the same standard: do less, do it beautifully, never compromise on safety."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/contact",
						className: "mt-10 inline-flex rounded-full bg-primary px-7 py-3.5 text-sm font-medium text-primary-foreground hover:opacity-90",
						children: "Meet the team"
					})
				] })]
			})
		})
	] });
}
//#endregion
export { About as component };
