//#region node_modules/.nitro/vite/services/ssr/assets/treatment-room-DbGIap6I.js
var treatment_room_default = "/assets/treatment-room-BitRXQsG.jpg";
//#endregion
export { treatment_room_default as t };
