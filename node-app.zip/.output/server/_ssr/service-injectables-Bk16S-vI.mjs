//#region node_modules/.nitro/vite/services/ssr/assets/service-injectables-Bk16S-vI.js
var service_injectables_default = "/assets/service-injectables-D2ndW2N5.jpg";
//#endregion
export { service_injectables_default as t };
