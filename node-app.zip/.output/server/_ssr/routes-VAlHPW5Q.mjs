import { r as __toESM } from "../_runtime.mjs";
import { t as interior_default } from "./interior-CDS_0LbP.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as service_injectables_default } from "./service-injectables-Bk16S-vI.mjs";
import { t as service_skin_default } from "./service-skin-Dzrbnfhw.mjs";
import { t as service_laser_default } from "./service-laser-DmmFyV4a.mjs";
import { t as service_lifting_default } from "./service-lifting-Dr5OfZM1.mjs";
import { t as service_surgery_default } from "./service-surgery-Dmievn9d.mjs";
import { t as wellness_default } from "./wellness-BF4dqQWl.mjs";
import { t as hero_default } from "./hero-Dvd-gcVk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-VAlHPW5Q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var doctor_1_default = "/assets/doctor-1-Dko9X97V.jpg";
var doctor_2_default = "/assets/doctor-2-fssWe7B1.jpg";
var doctor_3_default = "/assets/doctor-3-DD_j19KX.jpg";
var pillars = [
	{
		title: "Excellence in every detail",
		body: "Lumière Clinic is a multidisciplinary aesthetic, plastic surgery and wellness center where scientific expertise and a personalized approach guide every transformation."
	},
	{
		title: "Health and beauty 360",
		body: "Our 360-degree approach provides comprehensive care. We celebrate diversity by creating a space that respects each client's definition of beauty."
	},
	{
		title: "Luxury interiors",
		body: "Soft curves, warm lighting and a soothing atmosphere — a space designed to put you at ease, because true beauty begins with how you feel."
	},
	{
		title: "A signature experience",
		body: "Each client is an individual story. Each transformation is life-changing, and we ensure it brings pure joy from the first consultation onward."
	}
];
var services = [
	{
		num: "01",
		title: "Cosmetic Injectables",
		image: service_injectables_default,
		tags: [
			"Botox",
			"Fillers",
			"Profhilo",
			"Lip enhancement"
		],
		body: "Subtle, natural movement — softening lines and restoring balance.",
		to: "/services/injectables",
		cta: "Explore injectables"
	},
	{
		num: "02",
		title: "Skin & HydraFacial",
		image: service_skin_default,
		tags: [
			"HydraFacial",
			"Chemical peels",
			"Mesotherapy",
			"Microneedling"
		],
		body: "Medical-grade facials and resurfacing for clear, luminous skin.",
		to: "/services/skin",
		cta: "Explore skin"
	},
	{
		num: "03",
		title: "Laser & Hair Removal",
		image: service_laser_default,
		tags: [
			"Laser hair",
			"Pigmentation",
			"Vascular",
			"Tattoo removal"
		],
		body: "Advanced laser platforms, safe across all Fitzpatrick skin types.",
		to: "/services/laser",
		cta: "Explore laser"
	},
	{
		num: "04",
		title: "Anti-Aging & Lifting",
		image: service_lifting_default,
		tags: [
			"Morpheus8",
			"Ultherapy",
			"Threads",
			"Fotona 4D"
		],
		body: "Non-surgical tightening and collagen renewal with real downtime answers.",
		to: "/services/lifting",
		cta: "Explore lifting"
	},
	{
		num: "05",
		title: "Plastic Surgery",
		image: service_surgery_default,
		tags: [
			"Rhinoplasty",
			"Liposuction",
			"Eyelid surgery",
			"Breast"
		],
		body: "Board-certified surgeons for considered, beautifully natural results.",
		to: "/services/surgery",
		cta: "Explore surgery"
	},
	{
		num: "06",
		title: "Wellness & Longevity",
		image: wellness_default,
		tags: [
			"IV drips",
			"Hormone health",
			"Hair restoration",
			"Skin boosters"
		],
		body: "Feel as good as you look — inside-out care for energy and vitality.",
		to: "/services/wellness",
		cta: "Explore wellness"
	}
];
var doctors = [
	{
		name: "Dr. Layla Haddad",
		role: "Medical Director · Dermatology",
		credentials: "MD, FAAD — 15+ years",
		image: doctor_1_default
	},
	{
		name: "Dr. Adrien Moreau",
		role: "Aesthetic & Laser Medicine",
		credentials: "MD, EBCD — Paris trained",
		image: doctor_2_default
	},
	{
		name: "Dr. Noor Khalil",
		role: "Plastic & Reconstructive Surgery",
		credentials: "MD, FRCS — London board",
		image: doctor_3_default
	}
];
var testimonials = [
	{
		quote: "I've never felt more myself. The team listens — nothing is rushed, nothing overdone.",
		name: "Amina R.",
		detail: "HydraFacial · Profhilo"
	},
	{
		quote: "Refined, discreet, and deeply professional. The results look like me, just rested.",
		name: "Sophie L.",
		detail: "Injectables · Morpheus8"
	},
	{
		quote: "From the consultation to follow-up, every detail felt considered. A true sanctuary.",
		name: "Maya K.",
		detail: "Laser · Skin boosters"
	}
];
function Home() {
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		phone: "",
		service: "Cosmetic injectables (Botox / Fillers)"
	});
	const [sent, setSent] = (0, import_react.useState)(false);
	const onChange = (e) => {
		setForm({
			...form,
			[e.target.name]: e.target.value
		});
	};
	const onSubmit = (e) => {
		e.preventDefault();
		const text = `Hello Lumière Clinic, I'd like to request a consultation.%0A%0AName: ${form.name}%0APhone: ${form.phone}%0AArea of Interest: ${form.service}`;
		window.open(`https://wa.me/971543251817?text=${text}`, "_blank");
		setSent(true);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative bg-background overflow-hidden pt-28 pb-16 lg:pt-36 lg:pb-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-0 opacity-[0.08] mix-blend-multiply pointer-events-none",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: hero_default,
					alt: "",
					className: "w-full h-full object-cover"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative z-10 mx-auto max-w-7xl px-6 lg:px-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-12 lg:grid-cols-12 lg:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:col-span-7 flex flex-col justify-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow text-primary font-semibold mb-4 tracking-[0.25em]",
								children: "Aesthetic Medicine · Dubai"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "font-display text-4xl leading-[1.1] text-foreground sm:text-5xl md:text-6xl lg:text-[4rem] xl:text-[4.5rem]",
								children: [
									"Aesthetic medicine",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"in Dubai, refined by ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "italic font-light text-primary",
										children: "artistry."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 max-w-xl text-base md:text-lg leading-relaxed text-muted-foreground",
								children: "Doctor-led injectables, skin, laser and surgical care — designed around natural, lasting results and a calm, considered experience."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-12 pt-8 border-t border-border/60 flex flex-wrap items-center gap-x-10 gap-y-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-3xl font-normal text-foreground",
										children: "4.9★"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-sans font-semibold tracking-wider text-muted-foreground uppercase mt-1",
										children: "1,280 reviews"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-[1px] h-10 bg-border/60 hidden sm:block" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-3xl font-normal text-foreground",
										children: "14"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-sans font-semibold tracking-wider text-muted-foreground uppercase mt-1",
										children: "years in dubai"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-[1px] h-10 bg-border/60 hidden sm:block" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-3xl font-normal text-foreground",
										children: "40k+"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-sans font-semibold tracking-wider text-muted-foreground uppercase mt-1",
										children: "treatments"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-[1px] h-10 bg-border/60 hidden sm:block" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-3xl font-normal text-foreground",
										children: "DHA"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-sans font-semibold tracking-wider text-muted-foreground uppercase mt-1",
										children: "licensed doctors"
									})] })
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:col-span-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-background rounded-2xl border border-border/80 p-8 shadow-xl relative z-10 max-w-md mx-auto lg:mr-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl text-foreground mb-1",
									children: "Request your consultation"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-muted-foreground tracking-wide font-light mb-6",
									children: "A specialist replies within 15 minutes during clinic hours."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit,
									className: "space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-semibold tracking-wider text-muted-foreground uppercase mb-1.5 pl-0.5",
											children: "Full name"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											type: "text",
											name: "name",
											value: form.name,
											onChange,
											placeholder: "Your name",
											className: "w-full rounded-lg border border-border/80 bg-background/50 px-4 py-2.5 text-sm outline-none focus:border-primary transition-all font-light"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-semibold tracking-wider text-muted-foreground uppercase mb-1.5 pl-0.5",
											children: "Mobile number"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											type: "tel",
											name: "phone",
											value: form.phone,
											onChange,
											placeholder: "+971 5X XXX XXXX",
											className: "w-full rounded-lg border border-border/80 bg-background/50 px-4 py-2.5 text-sm outline-none focus:border-primary transition-all font-light"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "block text-[10px] font-semibold tracking-wider text-muted-foreground uppercase mb-1.5 pl-0.5",
											children: "Area of interest"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											name: "service",
											value: form.service,
											onChange,
											className: "w-full rounded-lg border border-border/80 bg-background/50 px-4 py-2.5 text-sm outline-none focus:border-primary transition-all font-light appearance-none",
											style: {
												backgroundImage: `url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e")`,
												backgroundRepeat: "no-repeat",
												backgroundPosition: "right 1rem center",
												backgroundSize: "1em"
											},
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Cosmetic injectables (Botox / Fillers)" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Skin & HydraFacial" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Laser & Hair Removal" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Anti-Aging & Lifting" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Plastic Surgery" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Wellness & Longevity" })
											]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "submit",
											className: "w-full mt-2 rounded-lg bg-primary py-3 text-sm font-medium text-primary-foreground hover:opacity-95 transition-all shadow-sm flex items-center justify-center gap-1.5 cursor-pointer",
											children: "Request consultation →"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative flex py-2 items-center justify-center",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-grow border-t border-border/60" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "flex-shrink mx-4 text-[9px] uppercase tracking-widest text-muted-foreground/80 font-light",
													children: "or reply faster on"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-grow border-t border-border/60" })
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: "https://wa.me/971543251817",
											target: "_blank",
											rel: "noreferrer",
											className: "w-full rounded-lg bg-[#125e46] py-3 text-sm font-medium text-white hover:opacity-95 transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
												className: "w-4 h-4 fill-white",
												viewBox: "0 0 24 24",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12.012 2c-5.506 0-9.989 4.478-9.99 9.984a9.96 9.96 0 0 0 1.333 4.982L2 22l5.202-1.364a9.994 9.994 0 0 0 4.81 1.233c5.505 0 9.99-4.477 9.99-9.985C22.002 6.478 17.518 2 12.012 2zm0 18.29a8.27 8.27 0 0 1-4.222-1.155l-.304-.18-3.136.82.834-3.056-.198-.314A8.273 8.273 0 0 1 3.72 11.98c0-4.57 3.719-8.285 8.297-8.285 4.574 0 8.29 3.717 8.29 8.288 0 4.57-3.714 8.29-8.29 8.29-.003 0-.003 0 0 0z" })
											}), "WhatsApp the clinic"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[10px] text-center text-muted-foreground/80 mt-4 tracking-wide font-light flex items-center justify-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
												className: "w-3 h-3 text-muted-foreground/60",
												fill: "none",
												stroke: "currentColor",
												strokeWidth: "2",
												viewBox: "0 0 24 24",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
													x: "3",
													y: "11",
													width: "18",
													height: "11",
													rx: "2",
													ry: "2"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M7 11V7a5 5 0 0 1 10 0v4" })]
											}), "Your details stay private. No spam, ever."]
										})
									]
								})
							]
						})
					})]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-7xl px-6 py-28 lg:px-10 lg:py-40",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-14 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow mb-6",
							children: "Our history"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "font-display text-4xl leading-tight text-foreground md:text-5xl",
							children: [
								"A guide on your ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
									className: "italic",
									children: "wellness and beauty"
								}),
								" transformation journey."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 max-w-md text-base leading-relaxed text-muted-foreground",
							children: "Lumière is the meeting point of medical precision and refined hospitality — an environment where science, artistry and care work as one."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-7",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-px overflow-hidden rounded-2xl bg-border/70 sm:grid-cols-2",
						children: pillars.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "bg-background p-8 sm:p-10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-2xl text-foreground",
								children: p.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-sm leading-relaxed text-muted-foreground",
								children: p.body
							})]
						}, p.title))
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "relative",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl gap-10 px-6 py-20 lg:grid-cols-2 lg:items-center lg:gap-20 lg:px-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-hidden rounded-2xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: interior_default,
						alt: "Clinic interior with soft warm lighting",
						loading: "lazy",
						width: 1600,
						height: 1200,
						className: "aspect-[5/6] w-full object-cover transition-transform duration-700 hover:scale-105"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-6",
						children: "The Lumière space"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-4xl leading-tight md:text-5xl",
						children: [
							"An interior that ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
								className: "italic",
								children: "restores"
							}),
							" before treatment begins."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-base leading-relaxed text-muted-foreground",
						children: "From the moment you step inside, you feel the difference. Curved walls, warm lighting and an unhurried rhythm create a sanctuary that supports the best possible results."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/about",
						className: "mt-10 inline-flex items-center gap-2 text-sm tracking-wide text-foreground underline-offset-8 hover:underline",
						children: "Discover our story →"
					})
				] })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "services",
			className: "bg-secondary/30",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-6 py-28 lg:px-10 lg:py-36",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-14 flex flex-col items-start justify-between gap-6 md:flex-row md:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-4",
						children: "What we do"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-4xl md:text-5xl",
						children: [
							"Dermatology, refined into ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
								className: "italic",
								children: "an experience"
							}),
							"."
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-sm text-sm text-muted-foreground",
						children: "Six disciplines under one roof — medical-grade skin, injectables, laser, lifting, surgery and longevity."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-8 sm:grid-cols-2 lg:grid-cols-3",
					children: services.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: s.to,
						className: "group flex flex-col overflow-hidden rounded-2xl bg-background shadow-soft transition-transform hover:-translate-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: s.image,
								alt: s.title,
								loading: "lazy",
								width: 1024,
								height: 768,
								className: "aspect-[4/3] w-full object-cover transition-transform duration-[1200ms] group-hover:scale-105"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute left-5 top-5 rounded-full bg-background/85 px-3 py-1 text-xs uppercase tracking-[0.22em] text-foreground backdrop-blur-sm",
								children: s.num
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-1 flex-col p-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl text-foreground",
									children: s.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4 flex flex-wrap gap-2",
									children: s.tags.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full border border-border/70 px-3 py-1 text-xs text-muted-foreground",
										children: t
									}, t))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 text-sm leading-relaxed text-muted-foreground",
									children: s.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-auto pt-6 inline-flex items-center text-sm text-foreground underline-offset-8 group-hover:underline",
									children: [s.cta, " →"]
								})
							]
						})]
					}, s.num))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "offers",
			className: "bg-background",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-6 py-28 lg:px-10 lg:py-36",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-14",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-4 text-primary font-semibold",
						children: "Current Offers"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-4xl md:text-5xl",
						children: [
							"Seasonal packages, ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
								className: "italic",
								children: "thoughtfully priced"
							}),
							"."
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-8 md:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-background rounded-2xl border border-border/60 p-8 shadow-sm flex flex-col justify-between relative group hover:shadow-md transition-shadow",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute top-4 right-4 bg-[#c2a476]/15 text-[#91713d] text-[10px] font-sans font-semibold tracking-wider px-3 py-1 rounded-full uppercase",
									children: "Save 30%"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-2xl text-foreground mt-4 mb-1",
										children: "HydraFacial Trio"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-muted-foreground tracking-wide font-light mb-6",
										children: "Valid until 30 Sept 2026"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline gap-3 mb-8",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm text-muted-foreground line-through",
											children: "AED 1,500"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-2xl font-display font-medium text-foreground font-semibold",
											children: "AED 1,050"
										})]
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "https://wa.me/971543251817?text=Hi,%20I'd%20like%20to%20claim%20the%20HydraFacial%20Trio%20offer.",
									target: "_blank",
									rel: "noreferrer",
									className: "w-full text-center rounded-lg border border-border py-3 text-sm font-medium text-foreground hover:bg-muted/50 transition-all cursor-pointer",
									children: "Claim offer"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-background rounded-2xl border border-border/60 p-8 shadow-sm flex flex-col justify-between relative group hover:shadow-md transition-shadow",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute top-4 right-4 bg-[#c2a476]/15 text-[#91713d] text-[10px] font-sans font-semibold tracking-wider px-3 py-1 rounded-full uppercase",
									children: "Popular"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-2xl text-foreground mt-4 mb-1",
										children: "Lips + Botox Combo"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-muted-foreground tracking-wide font-light mb-6",
										children: "Valid until 30 Sept 2026"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline gap-3 mb-8",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm text-muted-foreground line-through",
											children: "AED 2,400"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-2xl font-display font-medium text-foreground font-semibold",
											children: "AED 1,900"
										})]
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "https://wa.me/971543251817?text=Hi,%20I'd%20like%20to%20claim%20the%20Lips%20%2B%20Botox%20Combo%20offer.",
									target: "_blank",
									rel: "noreferrer",
									className: "w-full text-center rounded-lg border border-border py-3 text-sm font-medium text-foreground hover:bg-muted/50 transition-all cursor-pointer",
									children: "Claim offer"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-background rounded-2xl border border-border/60 p-8 shadow-sm flex flex-col justify-between relative group hover:shadow-md transition-shadow",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute top-4 right-4 bg-[#c2a476]/15 text-[#91713d] text-[10px] font-sans font-semibold tracking-wider px-3 py-1 rounded-full uppercase",
									children: "New"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-2xl text-foreground mt-4 mb-1",
										children: "Morpheus8 — 3 Sessions"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-muted-foreground tracking-wide font-light mb-6",
										children: "Valid until 30 Sept 2026"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline gap-3 mb-8",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm text-muted-foreground line-through",
											children: "AED 6,000"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-2xl font-display font-medium text-foreground font-semibold",
											children: "AED 4,200"
										})]
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "https://wa.me/971543251817?text=Hi,%20I'd%20like%20to%20claim%20the%20Morpheus8%203%20Sessions%20offer.",
									target: "_blank",
									rel: "noreferrer",
									className: "w-full text-center rounded-lg border border-border py-3 text-sm font-medium text-foreground hover:bg-muted/50 transition-all cursor-pointer",
									children: "Claim offer"
								})
							]
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "doctors",
			className: "mx-auto max-w-7xl px-6 py-28 lg:px-10 lg:py-36",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-14 flex flex-col items-start justify-between gap-6 md:flex-row md:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow mb-4",
					children: "Meet the team"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-4xl md:text-5xl",
					children: [
						"Board-certified ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
							className: "italic",
							children: "specialists"
						}),
						"."
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm text-sm text-muted-foreground",
					children: "A multidisciplinary team — trained across Paris, London and the GCC — collaborating on every plan."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-8 md:grid-cols-3",
				children: doctors.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "group",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden rounded-2xl bg-card",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: d.image,
							alt: d.name,
							loading: "lazy",
							width: 800,
							height: 1024,
							className: "aspect-[4/5] w-full object-cover transition-transform duration-[1200ms] group-hover:scale-105"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-2xl text-foreground",
								children: d.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: d.role
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs uppercase tracking-[0.18em] text-muted-foreground/80",
								children: d.credentials
							})
						]
					})]
				}, d.name))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			id: "results",
			className: "bg-secondary/40",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-6 py-28 lg:px-10 lg:py-36",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-14 max-w-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow mb-4",
						children: "In their words"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-4xl md:text-5xl",
						children: [
							"Care our clients ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
								className: "italic",
								children: "return for"
							}),
							"."
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-8 md:grid-cols-3",
					children: testimonials.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
						className: "flex h-full flex-col justify-between rounded-2xl bg-background p-8 shadow-soft sm:p-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
							className: "font-display text-2xl leading-snug text-foreground",
							children: [
								"\"",
								t.quote,
								"\""
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
							className: "mt-8 border-t border-border/60 pt-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-foreground",
								children: t.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs uppercase tracking-[0.18em] text-muted-foreground",
								children: t.detail
							})]
						})]
					}, t.name))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-primary text-ivory",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-4xl px-6 py-28 text-center lg:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow text-accent mb-6",
						children: "Begin your consultation"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-4xl leading-tight text-white md:text-5xl",
						children: [
							"Your face deserves a second opinion ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", { className: "hidden sm:inline" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
								className: "italic font-light",
								children: "worth trusting."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-2xl mx-auto text-sm md:text-base leading-relaxed text-white/80",
						children: "Book a private consultation with one of our doctors. No pressure, no obligation — just honest, expert guidance."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 flex flex-wrap justify-center items-center gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "https://wa.me/971543251817",
								target: "_blank",
								rel: "noreferrer",
								className: "rounded-lg bg-[#526452] px-6 py-3 text-sm font-medium text-white hover:bg-[#5d705d] transition-all shadow-sm cursor-pointer",
								children: "Book consultation"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "https://wa.me/971543251817",
								target: "_blank",
								rel: "noreferrer",
								className: "rounded-lg bg-[#184d3e] px-6 py-3 text-sm font-medium text-white hover:opacity-95 transition-all shadow-sm flex items-center gap-1.5 cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
									className: "w-4 h-4 fill-white",
									viewBox: "0 0 24 24",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12.012 2c-5.506 0-9.989 4.478-9.99 9.984a9.96 9.96 0 0 0 1.333 4.982L2 22l5.202-1.364a9.994 9.994 0 0 0 4.81 1.233c5.505 0 9.99-4.477 9.99-9.985C22.002 6.478 17.518 2 12.012 2zm0 18.29a8.27 8.27 0 0 1-4.222-1.155l-.304-.18-3.136.82.834-3.056-.198-.314A8.273 8.273 0 0 1 3.72 11.98c0-4.57 3.719-8.285 8.297-8.285 4.574 0 8.29 3.717 8.29 8.288 0 4.57-3.714 8.29-8.29 8.29-.003 0-.003 0 0 0z" })
								}), "WhatsApp us"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "tel:+97140000000",
								className: "rounded-lg border border-white/30 px-6 py-3 text-sm font-medium text-white hover:bg-white/10 transition-all cursor-pointer",
								children: "Call the clinic"
							})
						]
					})
				]
			})
		})
	] });
}
//#endregion
export { Home as component };
