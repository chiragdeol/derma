import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as service_skin_default } from "./service-skin-Dzrbnfhw.mjs";
import { t as ServiceTemplate } from "./ServiceTemplate-JigWVX2v.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services.skin-hwBoyMOB.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceTemplate, {
	heroImage: service_skin_default,
	eyebrow: "Service · Skin",
	titleLead: "Skin &",
	titleItalic: "HydraFacial.",
	heroSubtitle: "A complete skin programme — from medical diagnostics to signature facials that visibly transform tone, texture and clarity.",
	promiseTitleLead: "Healthy skin is",
	promiseTitleItalic: "the foundation.",
	promiseBody: "Every treatment is matched to a Visia skin analysis and a personalised home routine. We never sell single sessions — we build progressive courses with measurable outcomes.",
	treatmentsTitle: "Facials & resurfacing",
	treatments: [
		{
			name: "Signature HydraFacial",
			body: "Cleanse, exfoliate, extract and infuse in one luxurious protocol.",
			time: "60 min"
		},
		{
			name: "Chemical peels",
			body: "Customised acid blends for pigmentation, texture and acne.",
			time: "45 min"
		},
		{
			name: "Microneedling RF",
			body: "Collagen induction with radiofrequency for firmer, smoother skin.",
			time: "75 min"
		},
		{
			name: "Mesotherapy",
			body: "Micro-injected vitamins and amino acids for deep nourishment.",
			time: "30 min"
		},
		{
			name: "BB Glow",
			body: "Semi-permanent luminosity through nano-channelling.",
			time: "60 min"
		},
		{
			name: "Dermaplaning",
			body: "Gentle exfoliation that leaves skin instantly smoother.",
			time: "30 min"
		}
	],
	journey: [
		{
			step: "Diagnosis",
			body: "Visia imaging, dermatologist review and a written plan."
		},
		{
			step: "In-clinic",
			body: "Course of facials or medical resurfacing as indicated."
		},
		{
			step: "Home routine",
			body: "Curated cosmeceuticals matched to your skin's needs."
		},
		{
			step: "Re-assessment",
			body: "Quarterly imaging to track measurable improvement."
		}
	]
});
//#endregion
export { SplitComponent as component };
