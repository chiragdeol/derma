//#region node_modules/.nitro/vite/services/ssr/assets/about-D1gCRPDi.js
var about_default = "/assets/about-DCa5XqUK.jpg";
//#endregion
export { about_default as t };
