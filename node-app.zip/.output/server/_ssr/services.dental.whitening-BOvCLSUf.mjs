import { t as interior_default } from "./interior-CDS_0LbP.mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as ServiceTemplate } from "./ServiceTemplate-CSpspR7l.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services.dental.whitening-BOvCLSUf.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceTemplate, {
	division: "Dental",
	divisionUrl: "/services",
	categoryName: "Teeth Whitening",
	eyebrow: "Dental · Whitening",
	metaTitle: "Teeth Whitening in Sharjah | In-Clinic & Home — Al Nemah Dental",
	metaDesc: "Professional teeth whitening in Sharjah — up to 8 shades brighter, enamel-safe, with in-clinic and take-home options. Book your whitening at Al Nemah.",
	h1: "Teeth Whitening in Sharjah",
	intro: "Brighten your smile safely by up to eight shades — in-clinic for instant results or a take-home kit at your own pace.",
	highlights: [
		["Up to 8 shades", "Results"],
		["Enamel-safe", "Formula"],
		["Same day", "In-clinic"]
	],
	concerns: [
		"Coffee & tea stains",
		"Yellowing",
		"Dull smile",
		"Ageing teeth"
	],
	txIntro: "Choose the whitening approach that suits you.",
	treatments: [
		{
			name: "In-Clinic Whitening",
			body: "Medical-grade gel activated for an immediate, even lift.",
			tags: ["Fast", "Even"],
			duration: "45–60 min",
			price: "From AED 900"
		},
		{
			name: "Take-Home Kit",
			body: "Custom trays and gel to whiten gradually at home.",
			tags: ["Flexible", "Top-up"],
			duration: "1–2 weeks",
			price: "From AED 700"
		},
		{
			name: "Combined Package",
			body: "In-clinic result plus a take-home kit to maintain it.",
			tags: ["Best value", "Lasting"],
			duration: "45 min + home",
			price: "From AED 1,300"
		}
	],
	faqs: [
		{
			question: "Is it safe for enamel?",
			answer: "Yes — professional gels whiten without damaging enamel."
		},
		{
			question: "How long do results last?",
			answer: "Typically 12–18 months, longer with a top-up kit."
		},
		{
			question: "Will it cause sensitivity?",
			answer: "Any sensitivity is mild and temporary; we can pre-treat."
		}
	],
	related: [
		{
			slug: "/services/dental/cosmetic-dentistry",
			label: "Cosmetic Dentistry & Veneers"
		},
		{
			slug: "/services/dental/orthodontics",
			label: "Orthodontics"
		},
		{
			slug: "/services/dental/general",
			label: "General & Preventive"
		}
	],
	heroImage: interior_default,
	dental: true
});
//#endregion
export { SplitComponent as component };
