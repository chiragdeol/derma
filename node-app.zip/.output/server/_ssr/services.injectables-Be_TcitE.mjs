import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as service_injectables_default } from "./service-injectables-Bk16S-vI.mjs";
import { t as ServiceTemplate } from "./ServiceTemplate-CSpspR7l.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services.injectables-Be_TcitE.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceTemplate, {
	division: "Dermatology & Aesthetics",
	divisionUrl: "/services",
	categoryName: "Cosmetic Injectables",
	eyebrow: "Dermatology · Injectables",
	metaTitle: "Botox, Fillers & Profhilo in Sharjah | Injectables — Al Nemah",
	metaDesc: "Doctor-administered cosmetic injectables in Sharjah — Botox, dermal fillers, Profhilo and lip enhancement for natural, refined results. Book a consultation.",
	h1: "Cosmetic Injectables in Sharjah",
	intro: "Doctor-administered injectables for soft, natural rejuvenation — smoothing lines and restoring volume without ever looking overdone.",
	highlights: [
		["20–40 min", "Per session"],
		["Minimal", "Downtime"],
		["Doctor-led", "Every case"]
	],
	concerns: [
		"Forehead lines",
		"Crow's feet",
		"Frown lines",
		"Volume loss",
		"Thin lips",
		"Skin laxity"
	],
	txIntro: "Our full injectables menu — all mapped and performed by a doctor.",
	treatments: [
		{
			name: "Anti-Wrinkle (Botox)",
			body: "Relaxes targeted muscles to soften forehead, frown and eye lines.",
			tags: ["Fine lines", "Prevention"],
			duration: "20 min · No downtime",
			price: "From AED 900"
		},
		{
			name: "Dermal Fillers",
			body: "Restores volume and contour in cheeks, chin, jaw and under-eyes.",
			tags: ["Volume", "Contour"],
			duration: "30–40 min · Minimal",
			price: "From AED 1,500"
		},
		{
			name: "Profhilo",
			body: "Bio-remodelling that hydrates and firms skin across the face.",
			tags: ["Laxity", "Glow"],
			duration: "20 min · No downtime",
			price: "From AED 1,800"
		},
		{
			name: "Lip Enhancement",
			body: "Subtle, balanced lip shaping and hydration.",
			tags: ["Shape", "Hydration"],
			duration: "30 min · Minimal",
			price: "From AED 1,500"
		}
	],
	faqs: [
		{
			question: "Will I look frozen?",
			answer: "No — we dose conservatively so expression stays natural."
		},
		{
			question: "How long does it last?",
			answer: "Anti-wrinkle 3–4 months; fillers 6–12 months by area."
		},
		{
			question: "Does it hurt?",
			answer: "Minimal; fine needles and numbing keep it comfortable."
		}
	],
	related: [
		{
			slug: "/services/skin",
			label: "Skin & HydraFacial"
		},
		{
			slug: "/services/lifting",
			label: "Anti-Aging & Lifting"
		},
		{
			slug: "/services/laser",
			label: "Laser & Hair Removal"
		}
	],
	heroImage: service_injectables_default,
	dental: false
});
//#endregion
export { SplitComponent as component };
